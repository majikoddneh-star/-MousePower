using System.Text;
using System.Text.RegularExpressions;

namespace MousePower;

/// <summary>
/// A new implementation of the public HID++ packet format and battery reads.
/// It never changes pairing, notifications, profiles, lights, or device settings.
/// Protocol references are listed in THIRD_PARTY_NOTICES.md.
/// </summary>
internal sealed class LogitechProvider : IBatteryProvider
{
    public string Name => "Logitech HID++";

    public async Task<IReadOnlyList<BatteryDevice>> ScanAsync(CancellationToken cancellationToken)
    {
        var collections = HidNative.Enumerate().Where(IsHidppCollection).ToArray();
        var groups = collections.GroupBy(x => string.IsNullOrEmpty(x.ContainerId) || x.ContainerId == Guid.Empty.ToString()
            ? CollectionGroup(x.Path) : $"{x.VendorId:X4}:{x.ProductId:X4}:{x.ContainerId}", StringComparer.OrdinalIgnoreCase);
        using var gate = new SemaphoreSlim(4);
        var scans = groups.Select(async group =>
        {
            await gate.WaitAsync(cancellationToken);
            try { return await ScanGroupAsync(group.Key, group.ToArray(), cancellationToken); }
            finally { gate.Release(); }
        });
        return (await Task.WhenAll(scans)).SelectMany(x => x).ToArray();
    }

    private static bool IsHidppCollection(HidInfo info) =>
        info.VendorId == 0x046D &&
        ((info.UsagePage == 0xFF00 && info.Usage is 1 or 2) ||
         (info.UsagePage == 0xFF43 && info.Usage == 0x0202)) &&
        info.InputReportByteLength >= 7 && info.OutputReportByteLength >= 7 &&
        info.InputReportByteLength <= 64 && info.OutputReportByteLength <= 64;

    // Windows gives each top-level HID collection its own path and instance suffix.
    internal static string CollectionGroup(string path)
    {
        var normalized = Regex.Replace(path, "&col[0-9a-f]{2}", "", RegexOptions.IgnoreCase);
        return Regex.Replace(normalized, "&[0-9a-f]{4}(?=#)", "", RegexOptions.IgnoreCase);
    }

    private static async Task<IReadOnlyList<BatteryDevice>> ScanGroupAsync(string groupId, HidInfo[] infos,
        CancellationToken cancellationToken)
    {
        using var budget = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        budget.CancelAfter(TimeSpan.FromSeconds(7));
        var devices = new List<BatteryDevice>();
        var first = infos[0];
        var bluetooth = first.UsagePage == 0xFF43 ||
                        first.Path.Contains("bthenum", StringComparison.OrdinalIgnoreCase) ||
                        first.Path.Contains("bthle", StringComparison.OrdinalIgnoreCase);
        var receiver = !bluetooth && (first.ProductId & 0xFF00) == 0xC500;
        var connection = bluetooth ? "蓝牙" : receiver ? "2.4 GHz 接收器" : "USB";
        try
        {
            await using var transport = HidppTransport.Open(infos);
            if (transport is null)
                return new[] { UnknownReceiver(groupId, first, connection, "设备正被其他程序占用，或没有访问权限") };

            var indices = receiver ? Enumerable.Range(1, 6).Select(x => (byte)x) : new byte[] { 0xFF };
            foreach (var index in indices)
            {
                budget.Token.ThrowIfCancellationRequested();
                var probe = await transport.FeatureAsync(index, 0, 1, new byte[] { 0, 0, 0xA7 }, 300, budget.Token);
                if (probe is null) continue;
                var legacy = IsError(probe) && probe[2] == 0x8F && probe[5] == 0x01;
                if (!legacy && (IsError(probe) || probe.Length < 7 || probe[4] < 2 || probe[6] != 0xA7)) continue;

                var fallbackName = receiver ? $"Logitech 无线设备 #{index}" :
                    string.IsNullOrWhiteSpace(first.Product) ? "Logitech 无线设备" : first.Product;
                var name = fallbackName;
                var kind = "设备";
                if (!legacy)
                {
                    var namingFeature = await FeatureIndexAsync(transport, index, 0x0005, budget.Token);
                    if (namingFeature != 0)
                    {
                        var typeReply = await transport.FeatureAsync(index, namingFeature, 2, [], 400, budget.Token);
                        if (ValidPayload(typeReply, 1)) kind = DecodeKind(typeReply![4]);
                        name = await ReadNameAsync(transport, index, namingFeature, fallbackName, budget.Token);
                    }
                }
                else if (receiver)
                {
                    // Receiver information is a read-only HID++ 1.0 long register.
                    var paired = await transport.RegisterAsync(0xFF, 0xB5, [(byte)(0x20 + index - 1)], true, 300, budget.Token);
                    if (ValidPayload(paired, 8)) kind = DecodeLegacyKind((byte)(paired![11] & 0x0F));
                    var deviceName = await transport.RegisterAsync(0xFF, 0xB5, [(byte)(0x40 + index - 1)], true, 300, budget.Token);
                    if (ValidPayload(deviceName, 3))
                    {
                        var length = Math.Min(deviceName![5], deviceName.Length - 6);
                        if (length > 0) name = Encoding.UTF8.GetString(deviceName, 6, length).TrimEnd('\0');
                    }
                }

                if (kind != "鼠标" && kind != "设备" && !name.Contains(kind, StringComparison.OrdinalIgnoreCase))
                    name += $"（{kind}）";
                BatteryReading? reading = legacy
                    ? await ReadLegacyAsync(transport, index, budget.Token)
                    : await ReadModernAsync(transport, index, budget.Token);
                devices.Add(new BatteryDevice($"logitech:{groupId}:{index}", name, "罗技", connection,
                    reading?.Percent, reading?.Charging, reading?.Status ?? "设备未提供可读取的电量", reading?.Source ?? NameFor(legacy),
                    reading is null ? null : DateTimeOffset.Now)
                {
                    // Multiple receiver slots share a container; only direct links
                    // can use that identifier to merge Windows Bluetooth readings.
                    PhysicalId = !receiver && Guid.TryParse(first.ContainerId, out var container) && container != Guid.Empty
                        ? "container:" + container.ToString("D").ToLowerInvariant() : null
                });
            }
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested) { }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
        catch (System.ComponentModel.Win32Exception) { }
        cancellationToken.ThrowIfCancellationRequested();
        if (devices.Count == 0)
            devices.Add(UnknownReceiver(groupId, first, connection, "未收到设备电量；请移动鼠标唤醒后刷新"));
        return devices;
    }

    private static BatteryDevice UnknownReceiver(string id, HidInfo info, string connection, string status) =>
        new($"logitech:{id}:unknown", string.IsNullOrWhiteSpace(info.Product) ? "Logitech 接收器 / 设备" : info.Product,
            "罗技", connection, null, null, status, "Logitech HID++");

    private static string NameFor(bool legacy) => legacy ? "HID++ 1.0" : "HID++ 2.0";
    private static bool IsError(byte[] data) => data.Length >= 6 && data[2] is 0x8F or 0xFF;
    private static bool ValidPayload(byte[]? data, int count) => data is not null && !IsError(data) && data.Length >= 4 + count;

    private static async Task<byte> FeatureIndexAsync(HidppTransport transport, byte device, ushort feature, CancellationToken token)
    {
        var reply = await transport.FeatureAsync(device, 0, 0, [(byte)(feature >> 8), (byte)feature], 400, token);
        return ValidPayload(reply, 1) ? reply![4] : (byte)0;
    }

    private static async Task<string> ReadNameAsync(HidppTransport transport, byte device, byte feature, string fallback,
        CancellationToken token)
    {
        var lengthReply = await transport.FeatureAsync(device, feature, 0, [], 400, token);
        if (!ValidPayload(lengthReply, 1) || lengthReply![4] is 0 or > 96) return fallback;
        var length = lengthReply[4];
        var bytes = new List<byte>(length);
        while (bytes.Count < length)
        {
            var part = await transport.FeatureAsync(device, feature, 1, [(byte)bytes.Count], 400, token);
            if (!ValidPayload(part, 1)) return fallback;
            bytes.AddRange(part!.Skip(4).Take(length - bytes.Count));
        }
        return Encoding.UTF8.GetString(bytes.ToArray()).TrimEnd('\0');
    }

    private static async Task<BatteryReading?> ReadModernAsync(HidppTransport transport, byte device, CancellationToken token)
    {
        var unified = await FeatureIndexAsync(transport, device, 0x1004, token);
        if (unified != 0)
        {
            var capabilities = await transport.FeatureAsync(device, unified, 0, [], 400, token);
            var status = await transport.FeatureAsync(device, unified, 1, [], 500, token);
            if (ValidPayload(status, 4))
                return DecodeUnified(status!.AsSpan(4), ValidPayload(capabilities, 2) ? (capabilities![5] & 2) != 0 : null);
        }
        var legacyBattery = await FeatureIndexAsync(transport, device, 0x1000, token);
        if (legacyBattery != 0)
        {
            var status = await transport.FeatureAsync(device, legacyBattery, 0, [], 500, token);
            if (ValidPayload(status, 3)) return DecodeLevelStatus(status!.AsSpan(4));
        }
        // Do not turn a voltage measurement into a made-up precise percentage.
        var voltage = await FeatureIndexAsync(transport, device, 0x1001, token);
        if (voltage != 0)
        {
            var result = await transport.FeatureAsync(device, voltage, 0, [], 500, token);
            if (ValidPayload(result, 3))
            {
                var millivolts = (result![4] << 8) | result[5];
                var charging = (result[6] & 0x80) != 0 && (result[6] & 3) == 0;
                return new(null, charging, $"仅上报电压 {millivolts} mV，未提供百分比", "HID++ 0x1001 电压");
            }
        }
        return null;
    }

    private static async Task<BatteryReading?> ReadLegacyAsync(HidppTransport transport, byte device, CancellationToken token)
    {
        var charge = await transport.RegisterAsync(device, 0x0D, [], false, 400, token);
        if (ValidPayload(charge, 3)) return DecodeLegacyCharge(charge!.AsSpan(4));
        var band = await transport.RegisterAsync(device, 0x07, [], false, 400, token);
        return ValidPayload(band, 2) ? DecodeLegacyBand(band!.AsSpan(4)) : null;
    }

    internal sealed record BatteryReading(int? Percent, bool? Charging, string Status, string Source);

    internal static BatteryReading? DecodeUnified(ReadOnlySpan<byte> payload, bool? supportsPercentage)
    {
        if (payload.Length < 4) return null;
        // A zero byte on a device without state-of-charge capability is a sentinel.
        int? percent = supportsPercentage == true && payload[0] <= 100 ? payload[0] :
                       supportsPercentage is null && payload[0] is > 0 and <= 100 ? payload[0] : null;
        var band = payload[1] switch { 1 => "电量极低", 2 => "电量低", 4 => "电量良好", 8 => "电量充足", _ => "电量未知" };
        var status = payload[2] switch { 0 => "使用电池", 1 => "正在充电", 2 => "缓慢充电", 3 => "已充满", 4 => "充电异常", _ => "充电状态未知" };
        bool? charging = payload[2] switch { 1 or 2 => true, 0 or 3 => false, _ => null };
        return new(percent, charging, percent.HasValue ? status : $"{band}（设备未提供百分比）；{status}", "HID++ 0x1004");
    }

    internal static BatteryReading? DecodeLevelStatus(ReadOnlySpan<byte> payload)
    {
        if (payload.Length < 3) return null;
        int? percent = payload[0] is > 0 and <= 100 ? payload[0] : null;
        var status = payload[2] switch { 0 => "使用电池", 1 => "正在充电", 2 => "即将充满", 3 => "已充满", 4 => "缓慢充电", 5 => "电池类型无效", 6 => "温度异常", 7 => "充电异常", _ => "充电状态未知" };
        bool? charging = payload[2] switch { 1 or 2 or 4 => true, 0 or 3 => false, _ => null };
        return new(percent, charging, status, "HID++ 0x1000");
    }

    internal static BatteryReading? DecodeLegacyCharge(ReadOnlySpan<byte> payload)
    {
        if (payload.Length < 3) return null;
        int? percent = payload[0] <= 100 ? payload[0] : null;
        var charge = payload[2] & 0xF0;
        return new(percent, charge switch { 0x50 => true, 0x30 or 0x90 => false, _ => null },
            charge switch { 0x30 => "使用电池", 0x50 => "正在充电", 0x90 => "已充满", _ => "充电状态未知" }, "HID++ 1.0 0x0D");
    }

    internal static BatteryReading? DecodeLegacyBand(ReadOnlySpan<byte> payload)
    {
        if (payload.Length < 2) return null;
        var band = payload[0] switch { 1 => "电量极低", 3 => "电量低", 5 => "电量良好", 7 => "电量充足", _ => "电量未知" };
        bool? charging = (payload[1] & 0x21) == 0x21 ? true : payload[1] == 0 || (payload[1] & 0x22) == 0x22 ? false : null;
        return new(null, charging, $"{band}（设备只提供档位）" + (charging == true ? "；正在充电" : ""), "HID++ 1.0 0x07");
    }

    private static string DecodeKind(byte kind) => kind switch
    {
        0 => "键盘", 1 => "遥控器", 2 => "数字键盘", 3 => "鼠标", 4 => "触摸板", 5 => "轨迹球", 6 => "演示器", 7 => "接收器", 8 => "耳机", _ => "设备"
    };

    private static string DecodeLegacyKind(byte kind) => kind switch
    {
        1 => "键盘", 2 => "鼠标", 3 => "数字键盘", 4 => "演示器", 8 => "轨迹球", 9 => "触摸板", _ => "设备"
    };

    private sealed class HidppTransport : IAsyncDisposable
    {
        private sealed record Endpoint(HidInfo Info, FileStream Stream);
        private sealed record Pending(byte Device, byte Command, byte Function, TaskCompletionSource<byte[]> Completion);
        private readonly Endpoint[] endpoints;
        private readonly CancellationTokenSource lifetime = new();
        private readonly Task[] readers;
        private readonly object sync = new();
        private Pending? pending;
        private byte softwareId = 1;

        private HidppTransport(Endpoint[] endpoints)
        {
            this.endpoints = endpoints;
            readers = endpoints.Select(ReadLoopAsync).ToArray();
        }

        internal static HidppTransport? Open(IEnumerable<HidInfo> infos)
        {
            var endpoints = new List<Endpoint>();
            foreach (var info in infos)
            {
                try
                {
                    var stream = HidNative.OpenStream(info.Path);
                    if (stream is not null) endpoints.Add(new(info, stream));
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
            return endpoints.Count == 0 ? null : new(endpoints.ToArray());
        }

        internal Task<byte[]?> FeatureAsync(byte device, byte feature, int function, byte[] parameters, int timeout,
            CancellationToken token)
        {
            softwareId = (byte)(softwareId % 15 + 1);
            return ExchangeAsync(device, feature, (byte)((function << 4) | softwareId), parameters, timeout, token);
        }

        internal Task<byte[]?> RegisterAsync(byte device, byte register, byte[] parameters, bool longRegister,
            int timeout, CancellationToken token) =>
            ExchangeAsync(device, longRegister ? (byte)0x83 : (byte)0x81, register, parameters, timeout, token);

        private async Task<byte[]?> ExchangeAsync(byte device, byte command, byte function, byte[] parameters,
            int timeout, CancellationToken token)
        {
            // All our read requests fit in a short packet. A long reply may arrive
            // on the other Windows collection. Bluetooth exposes only long packets.
            // Preferring short packets also covers HID++ 1.0 peripherals.
            var endpoint = endpoints.FirstOrDefault(x => x.Info.OutputReportByteLength == 7) ??
                           endpoints.FirstOrDefault(x => x.Info.OutputReportByteLength >= 20);
            if (endpoint is null) return null;
            var data = new byte[endpoint.Info.OutputReportByteLength];
            data[0] = data.Length >= 20 ? (byte)0x11 : (byte)0x10;
            data[1] = device; data[2] = command; data[3] = function;
            parameters.AsSpan(0, Math.Min(parameters.Length, data.Length - 4)).CopyTo(data.AsSpan(4));
            var completion = new TaskCompletionSource<byte[]>(TaskCreationOptions.RunContinuationsAsynchronously);
            var request = new Pending(device, command, function, completion);
            lock (sync) pending = request;
            using var deadline = CancellationTokenSource.CreateLinkedTokenSource(token, lifetime.Token);
            deadline.CancelAfter(timeout);
            try
            {
                await endpoint.Stream.WriteAsync(data, deadline.Token);
                await endpoint.Stream.FlushAsync(deadline.Token);
                return await completion.Task.WaitAsync(deadline.Token);
            }
            catch (OperationCanceledException) when (!token.IsCancellationRequested) { return null; }
            catch (IOException) { return null; }
            catch (ObjectDisposedException) { return null; }
            finally { lock (sync) if (ReferenceEquals(pending, request)) pending = null; }
        }

        private async Task ReadLoopAsync(Endpoint endpoint)
        {
            var buffer = new byte[endpoint.Info.InputReportByteLength];
            try
            {
                while (!lifetime.IsCancellationRequested)
                {
                    var length = await endpoint.Stream.ReadAsync(buffer, lifetime.Token);
                    if (length == 0) break;
                    if (length < 4 || buffer[0] is not (0x10 or 0x11 or 0x12)) continue;
                    lock (sync)
                    {
                        var p = pending;
                        if (p is null || (buffer[1] != p.Device && !(p.Device == 0xFF && buffer[1] == 0))) continue;
                        var normal = buffer[2] == p.Command && buffer[3] == p.Function;
                        var error = length >= 6 && (buffer[2] is 0x8F or 0xFF) && buffer[3] == p.Command && buffer[4] == p.Function;
                        if (normal || error) p.Completion.TrySetResult(buffer.AsSpan(0, length).ToArray());
                    }
                }
            }
            catch (OperationCanceledException) { }
            catch (IOException) { }
            catch (ObjectDisposedException) { }
        }

        public async ValueTask DisposeAsync()
        {
            lifetime.Cancel();
            foreach (var endpoint in endpoints) endpoint.Stream.Dispose();
            try { await Task.WhenAll(readers).WaitAsync(TimeSpan.FromSeconds(1)); }
            catch (TimeoutException) { }
            lifetime.Dispose();
        }
    }
}
