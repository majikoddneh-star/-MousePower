using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32.SafeHandles;

namespace MousePower;

/// <summary>
/// Brand-independent Bluetooth mouse support. Uses the Windows device tree, the
/// Windows-reported battery property, and the standard BLE Battery Service.
/// No discovery, pairing, writes, driver installation, or external processes.
///
/// API/ABI references:
/// https://learn.microsoft.com/windows/win32/api/setupapi/nf-setupapi-setupdigetdevicepropertyw
/// https://learn.microsoft.com/windows/win32/api/bluetoothleapis/nf-bluetoothleapis-bluetoothgattgetcharacteristics
/// https://learn.microsoft.com/windows/win32/api/bluetoothleapis/nf-bluetoothleapis-bluetoothgattgetcharacteristicvalue
/// https://github.com/microsoft/win32metadata/blob/main/generation/WinSDK/RecompiledIdlHeaders/um/bthledef.h
/// The battery DEVPROPKEY is undocumented; it is an optional compatibility path,
/// never a promise that every Bluetooth mouse reports battery to Windows.
/// </summary>
internal sealed class BluetoothProvider : IBatteryProvider
{
    public string Name => "蓝牙 / 标准 BLE";

    private static readonly Guid MouseClass = new("4d36e96f-e325-11ce-bfc1-08002be10318");
    private static readonly Guid BatteryService = new("0000180f-0000-1000-8000-00805f9b34fb");
    private static readonly Guid GattServiceInterface = new("6e3bb679-4372-40c8-9eaa-4509df260cd8");
    private static readonly DevPropKey BatteryKey = new(new Guid("104ea319-6ee2-4701-bd47-8ddbf425bbe5"), 2);
    private static readonly DevPropKey ContainerKey = new(new Guid("8c7ed206-3f8a-4827-b3ab-ae9e1faefc6c"), 2);
    private static readonly Regex AddressPattern = new(@"(?:DEV_|BLUETOOTHDEVICE_)([0-9A-F]{12})", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    private readonly SemaphoreSlim _scanGate = new(1, 1);

    public async Task<IReadOnlyList<BatteryDevice>> ScanAsync(CancellationToken cancellationToken)
    {
        // Native GATT calls have OS timeouts rather than a cancellation API.
        // Serialize scans so repeated Refresh clicks cannot accumulate workers.
        await _scanGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            return await Task.Run(() => Scan(cancellationToken), cancellationToken).ConfigureAwait(false);
        }
        finally { _scanGate.Release(); }
    }

    private static IReadOnlyList<BatteryDevice> Scan(CancellationToken token)
    {
        IntPtr deviceSet = Native.SetupDiGetClassDevsW(IntPtr.Zero, null, IntPtr.Zero, 0x02 | 0x04);
        if (deviceSet == new IntPtr(-1)) throw new Win32Exception(Marshal.GetLastWin32Error(), "无法枚举蓝牙设备树");
        try
        {
            var nodes = ReadNodes(deviceSet, token);
            var byInstance = nodes.ToDictionary(n => n.Data.DevInst);
            var groups = new Dictionary<string, MouseGroup>(StringComparer.OrdinalIgnoreCase);

            foreach (var mouse in nodes.Where(IsMouse))
            {
                token.ThrowIfCancellationRequested();
                var chain = Ancestors(mouse, byInstance).ToArray();
                var bluetooth = chain.FirstOrDefault(n => IsRemoteBluetooth(n.Id));
                if (bluetooth is null) continue; // Wired and receiver mice belong to other providers.
                // Prefer the remote device root over its HID service node.
                var root = chain.FirstOrDefault(n => n.Id.StartsWith("BTHLE\\DEV_", StringComparison.OrdinalIgnoreCase)
                    || n.Id.StartsWith("BTHENUM\\DEV_", StringComparison.OrdinalIgnoreCase)) ?? bluetooth;
                var address = ExtractAddress(root.Id + " " + root.HardwareIds);
                string key = address.Length > 0 ? address : root.Id;
                if (!groups.TryGetValue(key, out var group))
                {
                    group = new MouseGroup(root, address);
                    groups.Add(key, group);
                }
                foreach (var ancestor in chain)
                {
                    group.Members.Add(ancestor.Data.DevInst);
                    if (ancestor.Container != Guid.Empty && IsRemoteBluetooth(ancestor.Id)) group.Containers.Add(ancestor.Container);
                    if (ancestor.Data.DevInst == root.Data.DevInst) break;
                }
            }

            if (groups.Count == 0) return Array.Empty<BatteryDevice>();

            foreach (var group in groups.Values)
            {
                // Include sibling battery/service nodes only when associated with
                // this physical Bluetooth device, never a common radio ancestor.
                var related = nodes.Where(n => BelongsTo(n, group, byInstance)).ToArray();
                foreach (var node in related.OrderByDescending(n => n.Data.DevInst == group.Root.Data.DevInst))
                {
                    token.ThrowIfCancellationRequested();
                    var data = node.Data;
                    var battery = ReadPercentProperty(deviceSet, ref data);
                    if (battery.HasValue)
                    {
                        group.Percent = battery;
                        group.Source = "Windows 蓝牙电量属性";
                        group.Status = "Windows 上报值；可能为缓存，设备采样时间未知";
                        break;
                    }
                }
                group.Brand = GuessBrand(string.Join(" ", related.Select(n => n.Name + " " + n.HardwareIds + " " + n.Manufacturer)), group.Root.Name);
            }

            // Some Windows BLE drivers expose Battery Service as its service UUID,
            // others also register the generic GATT service interface.
            var seenPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var interfaceClass in new[] { BatteryService, GattServiceInterface })
            {
                foreach (var service in EnumerateServicePaths(interfaceClass, token))
                {
                    if (!seenPaths.Add(service.Path)) continue;
                    byInstance.TryGetValue(service.DevInst, out var serviceNode);
                    if (interfaceClass != BatteryService
                        && !service.Path.Contains(BatteryService.ToString(), StringComparison.OrdinalIgnoreCase)
                        && !(serviceNode?.Id.Contains(BatteryService.ToString(), StringComparison.OrdinalIgnoreCase) ?? false)) continue;
                    var group = groups.Values.FirstOrDefault(g =>
                        (serviceNode is not null && BelongsTo(serviceNode, g, byInstance))
                        || (g.Address.Length > 0 && service.Path.Contains(g.Address, StringComparison.OrdinalIgnoreCase)));
                    if (group is null || group.SampleTime.HasValue) continue;
                    token.ThrowIfCancellationRequested();
                    // A missing standard service or access denied does not hide
                    // the mouse: a Windows battery value remains a valid fallback.
                    var reading = ReadGattBattery(service.Path, token);
                    if (reading.Percent.HasValue && (reading.Live || !group.Percent.HasValue))
                    {
                        group.Percent = reading.Percent;
                        group.SampleTime = reading.Live ? DateTimeOffset.Now : null;
                        group.Source = "BLE Battery Service 0x180F / 0x2A19";
                        group.Status = reading.Live ? "已从设备读取" : "Windows BLE 缓存值；设备采样时间未知";
                    }
                    else if (!group.Percent.HasValue && reading.Error is not null)
                    {
                        group.Status = reading.Error;
                    }
                }
            }

            return groups.Select(pair => new BatteryDevice(
                "bluetooth:" + pair.Key.ToUpperInvariant(),
                DisplayName(pair.Value.Root), pair.Value.Brand,
                pair.Value.Root.Id.StartsWith("BTHLE", StringComparison.OrdinalIgnoreCase) ? "蓝牙 BLE" : "蓝牙",
                pair.Value.Percent, null, pair.Value.Status, pair.Value.Source, pair.Value.SampleTime)
            {
                PhysicalId = PhysicalId(pair.Value)
            }).ToArray();
        }
        finally { Native.SetupDiDestroyDeviceInfoList(deviceSet); }
    }

    private static List<DeviceNode> ReadNodes(IntPtr set, CancellationToken token)
    {
        var nodes = new List<DeviceNode>();
        for (uint index = 0; ; index++)
        {
            token.ThrowIfCancellationRequested();
            var data = DeviceInfoData.Create();
            if (!Native.SetupDiEnumDeviceInfo(set, index, ref data))
            {
                int error = Marshal.GetLastWin32Error();
                if (error != 259) throw new Win32Exception(error, "枚举设备失败");
                break;
            }
            var instance = new StringBuilder(1024);
            if (!Native.SetupDiGetDeviceInstanceIdW(set, ref data, instance, (uint)instance.Capacity, out _)) continue;
            string name = ReadRegistryString(set, ref data, 0x0C);
            if (name.Length == 0) name = ReadRegistryString(set, ref data, 0);
            string hardware = ReadRegistryString(set, ref data, 1) + " " + ReadRegistryString(set, ref data, 2);
            string manufacturer = ReadRegistryString(set, ref data, 0x0B);
            uint? parent = Native.CM_Get_Parent(out uint parentInstance, data.DevInst, 0) == 0 ? parentInstance : null;
            Guid container = Guid.Empty;
            var containerBytes = ReadProperty(set, ref data, ContainerKey, out var type);
            if (type == 0x0D && containerBytes?.Length == 16) container = new Guid(containerBytes);
            nodes.Add(new DeviceNode(data, instance.ToString(), name, hardware, manufacturer, parent, container));
        }
        return nodes;
    }

    private static bool IsMouse(DeviceNode node) => node.Data.ClassGuid == MouseClass
        || node.HardwareIds.Contains("HID_DEVICE_SYSTEM_MOUSE", StringComparison.OrdinalIgnoreCase)
        || node.HardwareIds.Contains("HID_DEVICE_UP:0001_U:0002", StringComparison.OrdinalIgnoreCase);

    private static bool IsRemoteBluetooth(string id) => id.StartsWith("BTHLE\\", StringComparison.OrdinalIgnoreCase)
        || id.StartsWith("BTHLEDEVICE\\", StringComparison.OrdinalIgnoreCase)
        || id.StartsWith("BTHENUM\\", StringComparison.OrdinalIgnoreCase);

    private static IEnumerable<DeviceNode> Ancestors(DeviceNode start, IReadOnlyDictionary<uint, DeviceNode> nodes)
    {
        var visited = new HashSet<uint>();
        DeviceNode? node = start;
        while (node is not null && visited.Add(node.Data.DevInst) && visited.Count <= 32)
        {
            yield return node;
            node = node.Parent.HasValue && nodes.TryGetValue(node.Parent.Value, out var parent) ? parent : null;
        }
    }

    private static bool BelongsTo(DeviceNode node, MouseGroup group, IReadOnlyDictionary<uint, DeviceNode> nodes)
    {
        if (group.Members.Contains(node.Data.DevInst)) return true;
        if (group.Address.Length > 0 && ExtractAddress(node.Id + " " + node.HardwareIds).Equals(group.Address, StringComparison.OrdinalIgnoreCase)) return true;
        if (node.Container != Guid.Empty && group.Containers.Contains(node.Container)) return true;
        return Ancestors(node, nodes).Any(n => n.Data.DevInst == group.Root.Data.DevInst);
    }

    private static string ExtractAddress(string text)
    {
        var match = AddressPattern.Match(text);
        return match.Success ? match.Groups[1].Value.ToUpperInvariant() : "";
    }

    private static string DisplayName(DeviceNode node) => string.IsNullOrWhiteSpace(node.Name) ? "蓝牙鼠标" : node.Name;

    private static string? PhysicalId(MouseGroup group)
    {
        Guid container = group.Root.Container != Guid.Empty ? group.Root.Container : group.Containers.FirstOrDefault();
        return container == Guid.Empty ? null : "container:" + container.ToString("D").ToLowerInvariant();
    }

    private static string GuessBrand(string description, string deviceName)
    {
        string lower = description.ToLowerInvariant();
        if (lower.Contains("logitech") || lower.Contains("logicool") || lower.Contains("罗技") || lower.Contains("vid_046d") || lower.Contains("vid&0002046d")) return "罗技 Logitech";
        if (lower.Contains("razer") || lower.Contains("雷蛇") || lower.Contains("vid_1532") || lower.Contains("vid&00021532")) return "雷蛇 Razer";
        // Microsoft is also a generic Windows HID driver manufacturer; that
        // manufacturer string alone does not identify a Microsoft-branded mouse.
        if (deviceName.Contains("Microsoft", StringComparison.OrdinalIgnoreCase) || deviceName.Contains("微软")
            || lower.Contains("vid_045e") || lower.Contains("vid&0002045e")) return "微软 Microsoft";
        if (lower.Contains("steelseries") || lower.Contains("赛睿") || lower.Contains("vid_1038")) return "赛睿 SteelSeries";
        if (lower.Contains("corsair") || lower.Contains("海盗船") || lower.Contains("vid_1b1c")) return "美商海盗船 Corsair";
        if (lower.Contains("lenovo") || lower.Contains("联想") || lower.Contains("thinkpad")) return "联想 Lenovo";
        if (lower.Contains("dell") || lower.Contains("戴尔")) return "戴尔 Dell";
        if (lower.Contains("rapoo") || lower.Contains("雷柏")) return "雷柏 Rapoo";
        if (lower.Contains("asus") || lower.Contains("华硕")) return "华硕 ASUS";
        if (lower.Contains("hp inc") || lower.Contains("hewlett") || lower.Contains("惠普")) return "惠普 HP";
        if (lower.Contains("keychron")) return "Keychron";
        if (lower.Contains("apple") || lower.Contains("vid_05ac")) return "Apple";
        return "标准蓝牙";
    }

    private static int? ReadPercentProperty(IntPtr set, ref DeviceInfoData info)
    {
        byte[]? bytes = ReadProperty(set, ref info, BatteryKey, out uint type);
        if (bytes is null) return null;
        uint? value = type switch
        {
            0x03 when bytes.Length >= 1 => bytes[0],       // DEVPROP_TYPE_BYTE
            0x05 when bytes.Length >= 2 => BitConverter.ToUInt16(bytes, 0),
            0x07 when bytes.Length >= 4 => BitConverter.ToUInt32(bytes, 0),
            _ => null
        };
        return value is <= 100 ? (int)value.Value : null;
    }

    private static byte[]? ReadProperty(IntPtr set, ref DeviceInfoData info, DevPropKey key, out uint type)
    {
        type = 0;
        Native.SetupDiGetDevicePropertyW(set, ref info, ref key, out type, null, 0, out uint required, 0);
        if (required is 0 or > 65536) return null;
        var buffer = new byte[required];
        if (!Native.SetupDiGetDevicePropertyW(set, ref info, ref key, out type, buffer, (uint)buffer.Length, out required, 0)) return null;
        if (required < buffer.Length) Array.Resize(ref buffer, (int)required);
        return buffer;
    }

    private static string ReadRegistryString(IntPtr set, ref DeviceInfoData info, uint property)
    {
        var buffer = new byte[4096];
        if (!Native.SetupDiGetDeviceRegistryPropertyW(set, ref info, property, out _, buffer, (uint)buffer.Length, out uint required)) return "";
        return Encoding.Unicode.GetString(buffer, 0, (int)Math.Min(required, (uint)buffer.Length)).TrimEnd('\0').Replace('\0', ' ');
    }

    private static IEnumerable<ServicePath> EnumerateServicePaths(Guid interfaceClass, CancellationToken token)
    {
        IntPtr set = Native.SetupDiGetClassDevsForInterface(ref interfaceClass, null, IntPtr.Zero, 0x02 | 0x10);
        if (set == new IntPtr(-1)) yield break;
        try
        {
            for (uint index = 0; ; index++)
            {
                token.ThrowIfCancellationRequested();
                var data = new InterfaceData { Size = (uint)Marshal.SizeOf<InterfaceData>() };
                if (!Native.SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref interfaceClass, index, ref data)) break;
                Native.SetupDiGetDeviceInterfaceDetailW(set, ref data, IntPtr.Zero, 0, out uint required, IntPtr.Zero);
                if (required is < 8 or > 65536) continue;
                IntPtr detail = Marshal.AllocHGlobal((int)required);
                try
                {
                    Marshal.WriteInt32(detail, IntPtr.Size == 8 ? 8 : 6);
                    var device = DeviceInfoData.Create();
                    if (!Native.SetupDiGetDeviceInterfaceDetailWithInfo(set, ref data, detail, required, out _, ref device)) continue;
                    string? path = Marshal.PtrToStringUni(IntPtr.Add(detail, 4));
                    if (!string.IsNullOrEmpty(path)) yield return new ServicePath(path, device.DevInst);
                }
                finally { Marshal.FreeHGlobal(detail); }
            }
        }
        finally { Native.SetupDiDestroyDeviceInfoList(set); }
    }

    private static GattReading ReadGattBattery(string path, CancellationToken token)
    {
        using var file = Native.CreateFileW(path, 0x80000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
        if (file.IsInvalid) return new(null, false, "无法读取 BLE 服务；设备可能休眠、断开或被驱动限制");
        int hr = Native.BluetoothGATTGetCharacteristics(file, IntPtr.Zero, 0, IntPtr.Zero, out ushort count, 0);
        if ((hr != 0 && hr != unchecked((int)0x800700EA)) || count is 0 or > 256) return new(null, false, "未取得可读的标准 BLE 电量特征");
        int size = Marshal.SizeOf<GattCharacteristic>();
        IntPtr characters = Marshal.AllocHGlobal(size * count);
        try
        {
            hr = Native.BluetoothGATTGetCharacteristics(file, IntPtr.Zero, count, characters, out ushort actual, 0);
            if (hr != 0 || actual > count) return new(null, false, "BLE 特征读取失败");
            for (int i = 0; i < actual; i++)
            {
                token.ThrowIfCancellationRequested();
                var characteristic = Marshal.PtrToStructure<GattCharacteristic>(IntPtr.Add(characters, size * i));
                if (!characteristic.Uuid.Matches(0x2A19) || characteristic.IsReadable == 0) continue;
                // A Battery Level value is a single octet. A generous fixed buffer
                // avoids a second forced wireless read just to query its size.
                IntPtr value = Marshal.AllocHGlobal(64);
                try
                {
                    foreach (uint flags in new uint[] { 0x04, 0x08 })
                    {
                        token.ThrowIfCancellationRequested();
                        Marshal.WriteInt32(value, 0);
                        hr = Native.BluetoothGATTGetCharacteristicValue(file, ref characteristic, 64, value, out _, flags);
                        if (hr != 0) continue;
                        uint dataSize = unchecked((uint)Marshal.ReadInt32(value));
                        if (dataSize != 1) continue;
                        byte percent = Marshal.ReadByte(value, 4);
                        if (percent <= 100) return new(percent, flags == 0x04, null);
                    }
                }
                finally { Marshal.FreeHGlobal(value); }
            }
        }
        finally { Marshal.FreeHGlobal(characters); }
        return new(null, false, "未读取到电量；设备可能休眠或未实现标准 Battery Service");
    }

    private sealed record DeviceNode(DeviceInfoData Data, string Id, string Name, string HardwareIds, string Manufacturer, uint? Parent, Guid Container);
    private sealed record ServicePath(string Path, uint DevInst);
    private sealed record GattReading(int? Percent, bool Live, string? Error);
    private sealed class MouseGroup(DeviceNode root, string address)
    {
        public DeviceNode Root { get; } = root;
        public string Address { get; } = address;
        public HashSet<uint> Members { get; } = new();
        public HashSet<Guid> Containers { get; } = new();
        public string Brand { get; set; } = "标准蓝牙";
        public int? Percent { get; set; }
        public string Status { get; set; } = "已识别蓝牙鼠标；设备或驱动未上报可读电量";
        public string Source { get; set; } = "Windows 蓝牙设备树";
        public DateTimeOffset? SampleTime { get; set; }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DeviceInfoData
    {
        public uint Size;
        public Guid ClassGuid;
        public uint DevInst;
        public UIntPtr Reserved;
        public static DeviceInfoData Create() => new() { Size = (uint)Marshal.SizeOf<DeviceInfoData>() };
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct InterfaceData
    {
        public uint Size;
        public Guid ClassGuid;
        public uint Flags;
        public UIntPtr Reserved;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DevPropKey(Guid format, uint id)
    {
        public Guid Format = format;
        public uint Id = id;
    }

    // BOOLEAN is one byte in bthledef.h; Win32 BOOL would corrupt this ABI.
    [StructLayout(LayoutKind.Explicit, Size = 20, Pack = 4)]
    private struct GattUuid
    {
        [FieldOffset(0)] public byte IsShort;
        [FieldOffset(4)] public ushort Short;
        [FieldOffset(4)] public Guid Long;
        public readonly bool Matches(ushort uuid) => IsShort != 0 ? Short == uuid : Long == new Guid($"{uuid:x8}-0000-1000-8000-00805f9b34fb");
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    private struct GattCharacteristic
    {
        public ushort ServiceHandle;
        public GattUuid Uuid;
        public ushort AttributeHandle;
        public ushort ValueHandle;
        public byte IsBroadcastable;
        public byte IsReadable;
        public byte IsWritable;
        public byte IsWritableWithoutResponse;
        public byte IsSignedWritable;
        public byte IsNotifiable;
        public byte IsIndicatable;
        public byte HasExtendedProperties;
    }

    private static class Native
    {
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr SetupDiGetClassDevsW(IntPtr classGuid, string? enumerator, IntPtr parent, uint flags);
        [DllImport("setupapi.dll", EntryPoint = "SetupDiGetClassDevsW", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr SetupDiGetClassDevsForInterface(ref Guid classGuid, string? enumerator, IntPtr parent, uint flags);
        [DllImport("setupapi.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetupDiEnumDeviceInfo(IntPtr set, uint index, ref DeviceInfoData info);
        [DllImport("setupapi.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetupDiGetDeviceInstanceIdW(IntPtr set, ref DeviceInfoData info, StringBuilder id, uint size, out uint required);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetupDiGetDeviceRegistryPropertyW(IntPtr set, ref DeviceInfoData info, uint property, out uint type, byte[] buffer, uint size, out uint required);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetupDiGetDevicePropertyW(IntPtr set, ref DeviceInfoData info, ref DevPropKey key, out uint type, byte[]? buffer, uint size, out uint required, uint flags);
        [DllImport("cfgmgr32.dll")]
        public static extern uint CM_Get_Parent(out uint parent, uint device, uint flags);
        [DllImport("setupapi.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetupDiEnumDeviceInterfaces(IntPtr set, IntPtr device, ref Guid interfaceClass, uint index, ref InterfaceData data);
        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetupDiGetDeviceInterfaceDetailW(IntPtr set, ref InterfaceData data, IntPtr detail, uint size, out uint required, IntPtr device);
        [DllImport("setupapi.dll", EntryPoint = "SetupDiGetDeviceInterfaceDetailW", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetupDiGetDeviceInterfaceDetailWithInfo(IntPtr set, ref InterfaceData data, IntPtr detail, uint size, out uint required, ref DeviceInfoData device);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern SafeFileHandle CreateFileW(string name, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
        [DllImport("BluetoothAPIs.dll")]
        public static extern int BluetoothGATTGetCharacteristics(SafeFileHandle device, IntPtr service, ushort count, IntPtr characteristics, out ushort actual, uint flags);
        [DllImport("BluetoothAPIs.dll")]
        public static extern int BluetoothGATTGetCharacteristicValue(SafeFileHandle device, ref GattCharacteristic characteristic, uint size, IntPtr value, out ushort required, uint flags);
    }
}
