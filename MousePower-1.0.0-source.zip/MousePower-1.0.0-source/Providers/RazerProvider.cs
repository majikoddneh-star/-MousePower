using Microsoft.Win32.SafeHandles;
using System.Text.RegularExpressions;

namespace MousePower;

/// <summary>Read-only Razer battery commands, independently implemented from protocol facts.</summary>
internal sealed class RazerProvider : IBatteryProvider
{
    public string Name => "Razer HID";
    private readonly SemaphoreSlim _scanLock = new(1, 1);
    private readonly Dictionary<string, string> _workingPaths = new(StringComparer.OrdinalIgnoreCase);
    private sealed record Model(string Name, byte Transaction, string Connection, bool Rechargeable = true, int Delay = 100);

    // USB identifiers and transaction values verified against OpenRazer's mouse battery switch.
    // https://github.com/openrazer/openrazer/blob/master/driver/razermouse_driver.c
    private static readonly IReadOnlyDictionary<ushort, Model> Models = new Dictionary<ushort, Model>
    {
        [0x001F] = new("Razer Naga Epic", 0xFF, "USB / 充电线"),
        [0x0024] = new("Razer Mamba 2012", 0xFF, "USB / 充电线"),
        [0x0025] = new("Razer Mamba 2012", 0xFF, "2.4 GHz 接收器"),
        [0x0032] = new("Razer Ouroboros", 0xFF, "USB / 充电线"),
        [0x003E] = new("Razer Naga Epic Chroma", 0xFF, "USB / 充电线"),
        [0x003F] = new("Razer Naga Epic Chroma", 0xFF, "2.4 GHz 接收器"),
        [0x0044] = new("Razer Mamba Chroma", 0xFF, "USB / 充电线"),
        [0x0045] = new("Razer Mamba Chroma", 0xFF, "2.4 GHz 接收器"),
        [0x0059] = new("Razer Lancehead", 0x3F, "USB / 充电线"),
        [0x005A] = new("Razer Lancehead", 0x3F, "2.4 GHz 接收器"),
        [0x0062] = new("Razer Atheris", 0x1F, "2.4 GHz 接收器", false, 400),
        [0x006F] = new("Razer Lancehead Wireless", 0x1F, "2.4 GHz 接收器"),
        [0x0070] = new("Razer Lancehead Wireless", 0x1F, "USB / 充电线"),
        [0x0072] = new("Razer Mamba Wireless", 0x3F, "2.4 GHz 接收器"),
        [0x0073] = new("Razer Mamba Wireless", 0x3F, "USB / 充电线"),
        [0x0077] = new("Razer Pro Click", 0x1F, "2.4 GHz 接收器"),
        [0x007A] = new("Razer Viper Ultimate", 0xFF, "USB / 充电线"),
        [0x007B] = new("Razer Viper Ultimate", 0xFF, "2.4 GHz 接收器"),
        [0x007C] = new("Razer DeathAdder V2 Pro", 0x3F, "USB / 充电线"),
        [0x007D] = new("Razer DeathAdder V2 Pro", 0x3F, "2.4 GHz 接收器"),
        [0x0080] = new("Razer Pro Click", 0x1F, "USB / 充电线"),
        [0x0083] = new("Razer Basilisk X HyperSpeed", 0xFF, "2.4 GHz 接收器", false),
        [0x0086] = new("Razer Basilisk Ultimate", 0x1F, "USB / 充电线"),
        [0x0088] = new("Razer Basilisk Ultimate", 0x1F, "2.4 GHz 接收器"),
        [0x008F] = new("Razer Naga Pro", 0x1F, "USB / 充电线"),
        [0x0090] = new("Razer Naga Pro", 0x1F, "2.4 GHz 接收器"),
        [0x0094] = new("Razer Orochi V2", 0x1F, "2.4 GHz 接收器", false, 400),
        [0x0095] = new("Razer Orochi V2", 0x1F, "蓝牙", false, 400),
        [0x009A] = new("Razer Pro Click Mini", 0x1F, "2.4 GHz 接收器", false),
        [0x009C] = new("Razer DeathAdder V2 X HyperSpeed", 0x1F, "2.4 GHz 接收器", false),
        [0x009E] = new("Razer Viper Mini Signature Edition", 0x1F, "USB / 充电线"),
        [0x009F] = new("Razer Viper Mini Signature Edition", 0x1F, "2.4 GHz 接收器"),
        [0x00A5] = new("Razer Viper V2 Pro", 0x1F, "USB / 充电线"),
        [0x00A6] = new("Razer Viper V2 Pro", 0x1F, "2.4 GHz 接收器"),
        [0x00A7] = new("Razer Naga V2 Pro", 0x1F, "USB / 充电线"),
        [0x00A8] = new("Razer Naga V2 Pro", 0x1F, "2.4 GHz 接收器"),
        [0x00AA] = new("Razer Basilisk V3 Pro", 0x1F, "USB / 充电线"),
        [0x00AB] = new("Razer Basilisk V3 Pro", 0x1F, "2.4 GHz 接收器"),
        [0x00AF] = new("Razer Cobra Pro", 0x1F, "USB / 充电线"),
        [0x00B0] = new("Razer Cobra Pro", 0x1F, "2.4 GHz 接收器"),
        [0x00B3] = new("Razer HyperPolling Wireless Dongle", 0x1F, "2.4 GHz 接收器"),
        [0x00B4] = new("Razer Naga V2 HyperSpeed", 0x1F, "2.4 GHz 接收器", false),
        [0x00B6] = new("Razer DeathAdder V3 Pro", 0x1F, "USB / 充电线"),
        [0x00B7] = new("Razer DeathAdder V3 Pro", 0x1F, "2.4 GHz 接收器"),
        [0x00B8] = new("Razer Viper V3 HyperSpeed", 0x1F, "2.4 GHz 接收器", false),
        [0x00B9] = new("Razer Basilisk V3 X HyperSpeed", 0x1F, "2.4 GHz 接收器", false),
        [0x00BE] = new("Razer DeathAdder V4 Pro", 0x1F, "USB / 充电线"),
        [0x00BF] = new("Razer DeathAdder V4 Pro", 0x1F, "2.4 GHz 接收器"),
        [0x00C0] = new("Razer Viper V3 Pro", 0x1F, "USB / 充电线"),
        [0x00C1] = new("Razer Viper V3 Pro", 0x1F, "2.4 GHz 接收器"),
        [0x00C2] = new("Razer DeathAdder V3 Pro", 0x1F, "USB / 充电线"),
        [0x00C3] = new("Razer DeathAdder V3 Pro", 0x1F, "2.4 GHz 接收器"),
        [0x00C4] = new("Razer DeathAdder V3 HyperSpeed", 0x1F, "USB / 充电线"),
        [0x00C5] = new("Razer DeathAdder V3 HyperSpeed", 0x1F, "2.4 GHz 接收器"),
        [0x00C7] = new("Razer Pro Click V2 Vertical Edition", 0x1F, "USB / 充电线"),
        [0x00C8] = new("Razer Pro Click V2 Vertical Edition", 0x1F, "2.4 GHz 接收器"),
        [0x00CC] = new("Razer Basilisk V3 Pro 35K", 0x1F, "USB / 充电线"),
        [0x00CD] = new("Razer Basilisk V3 Pro 35K", 0x1F, "2.4 GHz 接收器"),
        [0x00D0] = new("Razer Pro Click V2", 0x1F, "USB / 充电线"),
        [0x00D1] = new("Razer Pro Click V2", 0x1F, "2.4 GHz 接收器"),
        [0x00D3] = new("Razer Basilisk Mobile", 0x1F, "USB / 充电线", false),
        [0x00D4] = new("Razer Basilisk Mobile", 0x1F, "2.4 GHz 接收器", false),
        [0x00D6] = new("Razer Basilisk V3 Pro 35K Phantom Green", 0x1F, "USB / 充电线"),
        [0x00D7] = new("Razer Basilisk V3 Pro 35K Phantom Green", 0x1F, "2.4 GHz 接收器"),
        [0x00DA] = new("Razer Cobra HyperSpeed", 0x1F, "USB / 充电线"),
        [0x00DB] = new("Razer Cobra HyperSpeed", 0x1F, "2.4 GHz 接收器"),
        [0x00DE] = new("Razer Viper V3 Pro SE", 0x1F, "USB / 充电线"),
        [0x00DF] = new("Razer Viper V3 Pro SE", 0x1F, "2.4 GHz 接收器")
    };

    public async Task<IReadOnlyList<BatteryDevice>> ScanAsync(CancellationToken cancellationToken)
    {
        await _scanLock.WaitAsync(cancellationToken);
        try { return await Task.Run(() => ScanCoreAsync(cancellationToken), cancellationToken); }
        finally { _scanLock.Release(); }
    }

    private async Task<IReadOnlyList<BatteryDevice>> ScanCoreAsync(CancellationToken cancellationToken)
    {
        var results = new List<BatteryDevice>();
        var groups = HidNative.Enumerate().Where(d => d.VendorId == 0x1532 && Models.ContainsKey(d.ProductId))
            .GroupBy(d => $"{d.ProductId:X4}:{PhysicalKey(d)}");
        foreach (var group in groups)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var first = group.First();
            var model = Models[first.ProductId];
            var source = $"Razer HID · 1532:{first.ProductId:X4}";
            var id = $"razer:{group.Key}";
            var physicalId = Guid.TryParse(first.ContainerId, out var containerGuid) && containerGuid != Guid.Empty
                ? "container:" + containerGuid.ToString().ToLowerInvariant() : null;
            var lastError = "设备未返回电量，请唤醒鼠标后刷新";
            BatteryDevice? found = null;
            var candidates = group.OrderByDescending(d => _workingPaths.GetValueOrDefault(group.Key) == d.Path)
                .ThenByDescending(d => d.FeatureReportByteLength >= 91)
                .ThenByDescending(d => d.UsagePage == 1 && d.Usage == 2).ToArray();
            foreach (var device in candidates)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (device.FeatureReportByteLength < 91) continue;
                try
                {
                    using var handle = HidNative.Open(device.Path);
                    if (handle is null) { lastError = "HID 接口暂时无法访问"; continue; }
                    var raw = await QueryAsync(handle, device, model, 0x80, cancellationToken);
                    bool? charging = null;
                    if (model.Rechargeable)
                    {
                        try { charging = await QueryAsync(handle, device, model, 0x84, cancellationToken) != 0; }
                        catch (IOException) { /* A battery reading remains useful when charging is unavailable. */ }
                    }
                    var percent = Math.Clamp((int)Math.Round(raw * 100.0 / 255, MidpointRounding.AwayFromZero), 0, 100);
                    found = new BatteryDevice(id, model.Name, "雷蛇 Razer", model.Connection, percent, charging,
                        charging == true ? "正在充电" : "已读取", source, DateTimeOffset.Now) { PhysicalId = physicalId };
                    _workingPaths[group.Key] = device.Path;
                    break;
                }
                catch (IOException ex) { lastError = ex.Message; }
                catch (UnauthorizedAccessException) { lastError = "HID 接口被其他程序占用"; }
            }
            results.Add(found ?? new BatteryDevice(id, model.Name, "雷蛇 Razer", model.Connection,
                null, null, lastError, source) { PhysicalId = physicalId });
        }
        return results;
    }

    private static string PhysicalKey(HidInfo device)
    {
        if (!string.IsNullOrWhiteSpace(device.ContainerId) && device.ContainerId != Guid.Empty.ToString()) return device.ContainerId;
        return Regex.Replace(device.Path.ToLowerInvariant(), @"&col[0-9a-f]{2}|&mi_[0-9a-f]{2}|&[0-9a-f]{4}(?=#)", "");
    }

    // Only 07/80 and 07/84 are accepted here; there are no configuration write commands.
    internal static byte[] BuildBatteryRequest(byte transaction, byte command, int length = 91)
    {
        if (command is not (0x80 or 0x84)) throw new ArgumentOutOfRangeException(nameof(command));
        if (length < 91 || length > 4096) throw new ArgumentOutOfRangeException(nameof(length));
        var report = new byte[length];
        report[2] = transaction;
        report[6] = 2;
        report[7] = 7;
        report[8] = command;
        report[89] = (byte)(2 ^ 7 ^ command);
        return report;
    }

    internal static bool ValidateBatteryResponse(byte[] report, byte transaction, byte command)
    {
        if (report.Length < 91 || report[0] != 0 || report[1] != 2 || report[2] != transaction ||
            report[3] != 0 || report[4] != 0 || report[5] != 0 || report[6] < 2 || report[6] > 80 ||
            report[7] != 7 || report[8] != command) return false;
        byte crc = 0;
        for (var i = 3; i < 89; i++) crc ^= report[i];
        return crc == report[89];
    }

    private static async Task<byte> QueryAsync(SafeFileHandle handle, HidInfo device, Model model,
        byte command, CancellationToken cancellationToken)
    {
        var request = BuildBatteryRequest(model.Transaction, command, device.FeatureReportByteLength);
        for (var attempt = 0; attempt < 3; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (!HidNative.SetFeature(handle, request, 1000, cancellationToken))
                throw new IOException("设备接口暂时无法读取；请唤醒鼠标后刷新");
            await Task.Delay(model.Delay, cancellationToken);
            var response = new byte[request.Length];
            if (!HidNative.GetFeature(handle, response, 1000, cancellationToken))
                throw new IOException("设备未响应，可能正在休眠或接口被占用");
            if (ValidateBatteryResponse(response, model.Transaction, command)) return response[10];
            if (response[1] == 5) throw new IOException("此设备固件不支持该电量查询");
            await Task.Delay(80, cancellationToken);
        }
        throw new IOException("未获得有效电量响应，请唤醒鼠标后刷新");
    }
}
