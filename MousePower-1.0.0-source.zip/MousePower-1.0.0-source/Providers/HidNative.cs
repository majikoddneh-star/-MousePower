using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Text;

namespace MousePower;

internal sealed record HidInfo(string Path, ushort VendorId, ushort ProductId,
    ushort UsagePage, ushort Usage, ushort InputReportByteLength,
    ushort OutputReportByteLength, ushort FeatureReportByteLength, string Product, string ContainerId = "");

/// <summary>Windows built-in HID APIs. No device driver replacement is required.</summary>
internal static class HidNative
{
    private const uint ShareReadWrite = 3, OpenExisting = 3, Overlapped = 0x40000000;
    private const uint GetFeatureIoctl = 0x000B0192, SetFeatureIoctl = 0x000B0191;

    public static IReadOnlyList<HidInfo> Enumerate()
    {
        var result = new List<HidInfo>();
        HidD_GetHidGuid(out var guid);
        var set = SetupDiGetClassDevs(ref guid, null, IntPtr.Zero, 0x12);
        if (set == new IntPtr(-1)) return result;
        try
        {
            for (uint index = 0; ; index++)
            {
                var data = new InterfaceData { Size = Marshal.SizeOf<InterfaceData>() };
                if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref guid, index, ref data)) break;
                SetupDiGetDeviceInterfaceDetail(set, ref data, IntPtr.Zero, 0, out var required, IntPtr.Zero);
                if (required < 8 || required > 65536) continue;
                var detail = Marshal.AllocHGlobal((int)required);
                try
                {
                    Marshal.WriteInt32(detail, IntPtr.Size == 8 ? 8 : 6);
                    var devInfo = new DeviceInfoData { Size = Marshal.SizeOf<DeviceInfoData>() };
                    if (!SetupDiGetDeviceInterfaceDetailWithInfo(set, ref data, detail, required, out _, ref devInfo)) continue;
                    var path = Marshal.PtrToStringUni(IntPtr.Add(detail, 4));
                    if (string.IsNullOrWhiteSpace(path)) continue;
                    using var handle = CreateFile(path, 0, ShareReadWrite, IntPtr.Zero, OpenExisting, 0, IntPtr.Zero);
                    if (handle.IsInvalid) continue;
                    var attrs = new Attributes { Size = Marshal.SizeOf<Attributes>() };
                    if (!HidD_GetAttributes(handle, ref attrs) || !HidD_GetPreparsedData(handle, out var prep)) continue;
                    try
                    {
                        if (HidP_GetCaps(prep, out var caps) < 0) continue;
                        var name = new StringBuilder(126);
                        HidD_GetProductString(handle, name, 252);
                        var key = new PropertyKey { FormatId = new Guid("8c7ed206-3f8a-4827-b3ab-ae9e1faefc6c"), PropertyId = 2 };
                        var container = new byte[16];
                        var containerId = SetupDiGetDeviceProperty(set, ref devInfo, ref key, out _, container, 16, out _, 0)
                            ? new Guid(container).ToString() : "";
                        result.Add(new HidInfo(path, attrs.VendorId, attrs.ProductId, caps.UsagePage,
                            caps.Usage, caps.InputLength, caps.OutputLength, caps.FeatureLength, name.ToString(), containerId));
                    }
                    finally { HidD_FreePreparsedData(prep); }
                }
                finally { Marshal.FreeHGlobal(detail); }
            }
        }
        finally { SetupDiDestroyDeviceInfoList(set); }
        return result;
    }

    /// <summary>Zero desired access allows feature requests to an OS-owned mouse collection.</summary>
    public static SafeFileHandle? Open(string path)
    {
        var handle = CreateFile(path, 0, ShareReadWrite, IntPtr.Zero, OpenExisting, Overlapped, IntPtr.Zero);
        if (!handle.IsInvalid) return handle;
        handle.Dispose();
        return null;
    }

    public static FileStream? OpenStream(string path)
    {
        var handle = CreateFile(path, 0xC0000000, ShareReadWrite, IntPtr.Zero, OpenExisting, Overlapped, IntPtr.Zero);
        if (handle.IsInvalid) { handle.Dispose(); return null; }
        try { return new FileStream(handle, FileAccess.ReadWrite, 1, isAsync: true); }
        catch { handle.Dispose(); throw; }
    }

    public static bool SetFeature(SafeFileHandle handle, byte[] report, int timeoutMs = 1200,
        CancellationToken cancellationToken = default) => FeatureIo(handle, report, false, timeoutMs, cancellationToken);

    public static bool GetFeature(SafeFileHandle handle, byte[] report, int timeoutMs = 1200,
        CancellationToken cancellationToken = default) => FeatureIo(handle, report, true, timeoutMs, cancellationToken);

    private static bool FeatureIo(SafeFileHandle handle, byte[] report, bool read, int timeoutMs,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        using var completed = new EventWaitHandle(false, EventResetMode.ManualReset);
        // Resolve the token's wait handle before any native request owns our buffers.
        // A disposed token source can throw here, which is safe before submission.
        var waits = cancellationToken.CanBeCanceled
            ? new WaitHandle[] { completed, cancellationToken.WaitHandle }
            : new WaitHandle[] { completed };
        var buffer = Marshal.AllocHGlobal(report.Length);
        var overlap = Marshal.AllocHGlobal(Marshal.SizeOf<NativeOverlap>());
        var pending = false;
        try
        {
            Marshal.Copy(report, 0, buffer, report.Length);
            Marshal.StructureToPtr(new NativeOverlap { Event = completed.SafeWaitHandle.DangerousGetHandle() }, overlap, false);
            var started = DeviceIoControl(handle, read ? GetFeatureIoctl : SetFeatureIoctl,
                buffer, (uint)report.Length, read ? buffer : IntPtr.Zero,
                read ? (uint)report.Length : 0, out _, overlap);
            if (!started && Marshal.GetLastWin32Error() != 997) return false;
            if (!started)
            {
                pending = true;
                var waited = WaitHandle.WaitAny(waits, timeoutMs);
                if (waited != 0)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    return false;
                }
            }
            var succeeded = GetOverlappedResult(handle, overlap, out _, false);
            // ERROR_IO_INCOMPLETE means the request still owns its native memory.
            // All other results mean completion, including a failed/cancelled I/O.
            if (succeeded || Marshal.GetLastWin32Error() != 996) pending = false;
            if (!succeeded) return false;
            if (read) Marshal.Copy(buffer, report, 0, report.Length);
            return true;
        }
        finally
        {
            if (pending)
            {
                // Covers timeouts, cancellation, and any unexpected exception in
                // WaitAny (including a concurrently disposed token source).
                // CancelIoEx alone does not guarantee completion; drain before free.
                CancelIoEx(handle, overlap);
                GetOverlappedResult(handle, overlap, out _, true);
            }
            Marshal.FreeHGlobal(overlap);
            Marshal.FreeHGlobal(buffer);
        }
    }

    [StructLayout(LayoutKind.Sequential)] private struct NativeOverlap
    {
        public UIntPtr Internal, InternalHigh;
        public uint Offset, OffsetHigh;
        public IntPtr Event;
    }
    [StructLayout(LayoutKind.Sequential)] private struct InterfaceData
    {
        public int Size;
        public Guid InterfaceClassGuid;
        public uint Flags;
        public UIntPtr Reserved;
    }
    [StructLayout(LayoutKind.Sequential)] private struct Attributes
    {
        public int Size;
        public ushort VendorId, ProductId, Version;
    }
    [StructLayout(LayoutKind.Sequential)] private struct DeviceInfoData
    {
        public int Size;
        public Guid ClassGuid;
        public uint DeviceInstance;
        public UIntPtr Reserved;
    }
    [StructLayout(LayoutKind.Sequential)] private struct PropertyKey
    {
        public Guid FormatId;
        public uint PropertyId;
    }
    [StructLayout(LayoutKind.Sequential)] private struct Caps
    {
        public ushort Usage, UsagePage, InputLength, OutputLength, FeatureLength;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)] public ushort[] Reserved;
        public ushort NumberLinkCollectionNodes, NumberInputButtonCaps, NumberInputValueCaps,
            NumberInputDataIndices, NumberOutputButtonCaps, NumberOutputValueCaps,
            NumberOutputDataIndices, NumberFeatureButtonCaps, NumberFeatureValueCaps, NumberFeatureDataIndices;
    }

    [DllImport("hid.dll")] private static extern void HidD_GetHidGuid(out Guid guid);
    [DllImport("hid.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.U1)]
    private static extern bool HidD_GetAttributes(SafeFileHandle handle, ref Attributes attributes);
    [DllImport("hid.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.U1)]
    private static extern bool HidD_GetPreparsedData(SafeFileHandle handle, out IntPtr data);
    [DllImport("hid.dll")] [return: MarshalAs(UnmanagedType.U1)]
    private static extern bool HidD_FreePreparsedData(IntPtr data);
    [DllImport("hid.dll")] private static extern int HidP_GetCaps(IntPtr data, out Caps caps);
    [DllImport("hid.dll", CharSet = CharSet.Unicode, SetLastError = true)] [return: MarshalAs(UnmanagedType.U1)]
    private static extern bool HidD_GetProductString(SafeFileHandle handle, StringBuilder buffer, int length);
    [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr SetupDiGetClassDevs(ref Guid guid, string? enumerator, IntPtr parent, uint flags);
    [DllImport("setupapi.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetupDiEnumDeviceInterfaces(IntPtr set, IntPtr device, ref Guid guid, uint index, ref InterfaceData data);
    [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr set, ref InterfaceData data, IntPtr detail, uint length, out uint required, IntPtr device);
    [DllImport("setupapi.dll", EntryPoint = "SetupDiGetDeviceInterfaceDetailW", CharSet = CharSet.Unicode, SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetupDiGetDeviceInterfaceDetailWithInfo(IntPtr set, ref InterfaceData data, IntPtr detail, uint length, out uint required, ref DeviceInfoData device);
    [DllImport("setupapi.dll", EntryPoint = "SetupDiGetDevicePropertyW", CharSet = CharSet.Unicode, SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetupDiGetDeviceProperty(IntPtr set, ref DeviceInfoData device, ref PropertyKey key, out uint propertyType,
        byte[] buffer, uint bufferSize, out uint requiredSize, uint flags);
    [DllImport("setupapi.dll")] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern SafeFileHandle CreateFile(string path, uint access, uint sharing, IntPtr security, uint creation, uint flags, IntPtr template);
    [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool DeviceIoControl(SafeFileHandle handle, uint code, IntPtr input, uint inputLength,
        IntPtr output, uint outputLength, out uint transferred, IntPtr overlapped);
    [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetOverlappedResult(SafeFileHandle handle, IntPtr overlap, out uint transferred, bool wait);
    [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CancelIoEx(SafeFileHandle handle, IntPtr overlap);
}
