using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace MousePower;

internal static class TrayArtwork
{
    public static readonly Color Accent = Color.FromArgb(71, 86, 223);
    [DllImport("user32.dll")] private static extern bool DestroyIcon(IntPtr hIcon);
    public static Icon Make(int? percent, bool? charging)
    {
        using var bitmap = new Bitmap(64, 64);
        using var graphics = Graphics.FromImage(bitmap);
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
        bool light = false;
        try { using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"); light = key?.GetValue("SystemUsesLightTheme") is int value && value == 1; } catch { }
        using var textBrush = new SolidBrush(light ? Color.FromArgb(25, 30, 48) : Color.White);
        string text = percent?.ToString() ?? "?";
        using var font = new Font("Segoe UI", text.Length == 3 ? 29 : 37, FontStyle.Bold, GraphicsUnit.Pixel);
        using var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        graphics.DrawString(text, font, textBrush, new RectangleF(-2, -3, 68, 57), format);
        using var track = new Pen(light ? Color.FromArgb(120, 130, 145) : Color.FromArgb(120, 215, 225, 235), 5) { StartCap = LineCap.Round, EndCap = LineCap.Round };
        graphics.DrawLine(track, 8, 58, 56, 58);
        if (percent.HasValue)
        {
            using var fill = new Pen(percent <= 20 ? Color.FromArgb(245, 116, 77) : charging == true ? Color.FromArgb(63, 184, 248) : Color.FromArgb(75, 212, 156), 5) { StartCap = LineCap.Round, EndCap = LineCap.Round };
            graphics.DrawLine(fill, 8, 58, 8 + Math.Max(1, percent.Value * 48 / 100f), 58);
        }
        IntPtr native = bitmap.GetHicon();
        try { return (Icon)Icon.FromHandle(native).Clone(); }
        finally { DestroyIcon(native); }
    }
}
