# 来源与组件声明

MousePower 的 C# 代码和图标为本项目新写实现（MIT）。以下开源项目和官方文档用于核实协议事实、数值及原生接口；没有将其 GPL 源代码复制、链接或捆入程序。

- Razer 设备 ID、事务值、电量命令和校验格式：[OpenRazer 鼠标驱动](https://github.com/openrazer/openrazer/blob/master/driver/razermouse_driver.c)、[OpenRazer 通用协议](https://github.com/openrazer/openrazer/blob/master/driver/razercommon.c)（参考项目 GPL-2.0）。
- Windows Razer 路径交叉核实：[xzeldon/razer-battery-report](https://github.com/xzeldon/razer-battery-report)；最终实现以验证成功的原生 HID 特征报告为准。
- Logitech 官方 [HID++ 格式](https://github.com/Logitech/cpg-docs/blob/master/hidpp20/README.rst) 及 [ROOT 功能](https://github.com/Logitech/cpg-docs/blob/master/hidpp20/features/0x0000-IRoot.rst)。
- Logitech 电量字段交叉核实：[Linux hid-logitech-hidpp.c](https://github.com/torvalds/linux/blob/master/drivers/hid/hid-logitech-hidpp.c)（GPL-2.0）、[Solaar hidpp20.py](https://github.com/pwr-Solaar/Solaar/blob/master/lib/logitech_receiver/hidpp20.py) / [hidpp10.py](https://github.com/pwr-Solaar/Solaar/blob/master/lib/logitech_receiver/hidpp10.py)（GPL-2.0-or-later）。
- Microsoft 原生 HID、SetupAPI、CfgMgr32 与 [Bluetooth GATT API](https://learn.microsoft.com/windows/win32/api/bluetoothleapis/nf-bluetoothleapis-bluetoothgattgetcharacteristicvalue)；[Windows SDK 原生结构](https://github.com/microsoft/win32metadata/blob/main/generation/WinSDK/RecompiledIdlHeaders/um/bthledef.h)。Windows 电量属性 GUID 为非正式公开兼容路径，不保证所有驱动提供。

分发程序包含 Microsoft .NET 8 与 Windows Desktop 运行时。其 MIT 许可证及完整第三方通知附于 `DOTNET-LICENSE.txt` 和 `DOTNET-THIRD-PARTY-NOTICES.txt`，它们按各自许可分发。应用不使用其他第三方 NuGet 运行时组件。

安装程序由 [Inno Setup](https://github.com/jrsoftware/issrc) 6.7.3 生成；其安装引擎按 Inno Setup 分发许可包含于安装包。简体中文语言文件取自其 [ChineseSimplified.isl](https://github.com/jrsoftware/issrc/blob/main/Files/Languages/ChineseSimplified.isl)，保留原维护者注释与归属。

Razer、Logitech、Microsoft 及其他品牌名称归各自所有者。本项目是独立工具。
