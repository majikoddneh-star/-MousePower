using MousePower;

int checks = 0;
void Check(bool condition, string name)
{
    if (!condition) throw new Exception(name);
    checks++;
}
byte[] Reply(byte value, byte status = 2)
{
    var packet = RazerProvider.BuildBatteryRequest(0x1f, 0x80);
    packet[1] = status;
    packet[10] = value;
    packet[89] ^= value;
    return packet;
}
var request = RazerProvider.BuildBatteryRequest(0x1f, 0x80);
Check(request.Length == 91, "Windows report length");
Check(request.Take(9).SequenceEqual(new byte[] { 0, 0, 0x1f, 0, 0, 0, 2, 7, 0x80 }), "Golden request header");
Check(request[89] == 0x85 && request[90] == 0, "Golden CRC and reserved");
Check(!RazerProvider.ValidateBatteryResponse(request, 0x1f, 0x80), "An echoed request is not a reading");
var reply = Reply(230);
Check(RazerProvider.ValidateBatteryResponse(reply, 0x1f, 0x80), "Valid battery response");
Check(Math.Round(reply[10] * 100.0 / 255) == 90, "Raw 230 scales to 90 percent");
Check(RazerProvider.ValidateBatteryResponse(Reply(0), 0x1f, 0x80), "A genuine zero-percent reading is valid");
Check(RazerProvider.ValidateBatteryResponse(Reply(255), 0x1f, 0x80), "A genuine full-charge reading is valid");
Check(!RazerProvider.ValidateBatteryResponse(Reply(0, 1), 0x1f, 0x80), "Busy never produces false zero-percent alert");
Check(!RazerProvider.ValidateBatteryResponse(Reply(0, 3), 0x1f, 0x80), "Failure is not battery success");
Check(!RazerProvider.ValidateBatteryResponse(Reply(0, 4), 0x1f, 0x80), "Sleeping device timeout is not zero-percent");
Check(!RazerProvider.ValidateBatteryResponse(Reply(0, 5), 0x1f, 0x80), "Unsupported is not battery success");
var bad = (byte[])reply.Clone(); bad[10] ^= 1;
Check(!RazerProvider.ValidateBatteryResponse(bad, 0x1f, 0x80), "Reject broken CRC");
bad = (byte[])reply.Clone(); bad[2] = 0x3f;
Check(!RazerProvider.ValidateBatteryResponse(bad, 0x1f, 0x80), "Reject different transaction");
bad = (byte[])reply.Clone(); bad[7] = 4; bad[89] ^= 7 ^ 4;
Check(!RazerProvider.ValidateBatteryResponse(bad, 0x1f, 0x80), "Reject another command class even with valid CRC");
bad = (byte[])reply.Clone(); bad[8] = 0x84; bad[89] ^= 0x80 ^ 0x84;
Check(!RazerProvider.ValidateBatteryResponse(bad, 0x1f, 0x80), "Charging reply cannot become battery level");
Check(!RazerProvider.ValidateBatteryResponse(new byte[20], 0x1f, 0x80), "Reject truncated packet");
bad = (byte[])reply.Clone(); bad[6] = 1; bad[89] ^= 2 ^ 1;
Check(!RazerProvider.ValidateBatteryResponse(bad, 0x1f, 0x80), "Reject missing battery argument");
bool blocked = false;
try { RazerProvider.BuildBatteryRequest(0x1f, 0x05); }
catch (ArgumentOutOfRangeException) { blocked = true; }
Check(blocked, "Block all configuration commands");
Console.WriteLine($"PASS {checks} Razer protocol checks");

namespace MousePower
{
    public record BatteryDevice(string Id, string Name, string Brand, string Connection, int? Percent,
        bool? Charging, string Status, string Source, DateTimeOffset? SampleTime = null)
    {
        public string? PhysicalId { get; init; }
    }
    public interface IBatteryProvider
    {
        string Name { get; }
        Task<IReadOnlyList<BatteryDevice>> ScanAsync(CancellationToken cancellationToken);
    }
}
