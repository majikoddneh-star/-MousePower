# Verification

Run from the MousePower source directory with the .NET 8 SDK on Windows:

```powershell
dotnet run --project Tests/Logitech/LogitechProtocolTests.csproj -c Release
dotnet run --project Tests/Razer/RazerProtocolTests.csproj -c Release
dotnet run --project Tests/Bluetooth/BluetoothHarness.csproj -c Release
dotnet run --project Tests/App/AppTests.csproj -c Release
```

The protocol harnesses exercise battery packet validation, sentinel handling and native Bluetooth structure layouts. Bluetooth also performs a read-only native scan; Logitech does so only when passed `-- --scan`.

The App harness tests the production settings, startup option, tray icon renderer and form with explicit fixture data. It also runs the real application message loop to verify hidden background launch, activation signals, close-to-tray behavior and quit; its initial hardware scan is read-only. It briefly changes the app's settings file and its current-user startup value, backs up both beforehand, and restores their original contents in `finally` blocks. Avoid changing those settings in the app while that harness is running. An optional final argument writes a fixture layout screenshot. No third-party test package is required.
