using MousePower;

int count = 0;
void Check(bool condition, string name) { if (!condition) throw new Exception(name); count++; }
var unified = LogitechProvider.DecodeUnified(new byte[] { 72, 4, 1, 1 }, true);
Check(unified is { Percent: 72, Charging: true }, "Unified measured percentage / charging");
Check(LogitechProvider.DecodeUnified(new byte[] { 0, 1, 0, 0 }, true)?.Percent == 0, "A measured zero percent is valid");
var coarse = LogitechProvider.DecodeUnified(new byte[] { 0, 4, 0, 0 }, false);
Check(coarse is { Percent: null, Charging: false } && coarse.Status.Contains("电量良好"), "Coarse-only device must not be reported as zero percent");
Check(LogitechProvider.DecodeUnified(new byte[] { 0, 1, 0, 0 }, null)?.Percent is null, "Unconfirmed zero sentinel is unknown");
Check(LogitechProvider.DecodeUnified(new byte[] { 255, 4, 4, 0 }, true) is { Percent: null, Charging: null }, "Invalid measurement and charge error");
Check(LogitechProvider.DecodeUnified(new byte[] { 96, 8, 2, 1 }, true)?.Charging == true, "Unified code 2 is slow charging");
Check(LogitechProvider.DecodeUnified(new byte[] { 100, 8, 3, 1 }, true)?.Charging == false, "Unified code 3 is full");
Check(LogitechProvider.DecodeUnified(new byte[] { 50, 4 }, true) is null, "Truncated unified frame is rejected");
Check(LogitechProvider.DecodeLevelStatus(new byte[] { 50, 20, 2 })?.Charging == true, "Legacy feature code 2 is almost full");
Check(LogitechProvider.DecodeLevelStatus(new byte[] { 50, 20, 4 })?.Charging == true, "Legacy feature code 4 is slow charging");
Check(LogitechProvider.DecodeLevelStatus(new byte[] { 0, 0, 0 })?.Percent is null, "Legacy feature zero is unknown");
Check(LogitechProvider.DecodeLegacyCharge(new byte[] { 63, 0, 0x50 }) is { Percent: 63, Charging: true }, "HID++ 1.0 percentage register");
Check(LogitechProvider.DecodeLegacyBand(new byte[] { 5, 0 }) is { Percent: null, Charging: false }, "HID++ 1.0 band must not become percentage");
var a = LogitechProvider.CollectionGroup(@"\\?\hid#vid_046d&pid_c52b&mi_02&col01#7&123&0&0000#{guid}");
var b = LogitechProvider.CollectionGroup(@"\\?\hid#vid_046d&pid_c52b&mi_02&col02#7&123&0&0001#{guid}");
Check(a == b, "Short and long collections group together");
Console.WriteLine($"PASS: {count} Logitech protocol vector checks");
if (args.Contains("--scan"))
{
    using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(12));
    var clock = System.Diagnostics.Stopwatch.StartNew();
    var devices = await new LogitechProvider().ScanAsync(timeout.Token);
    Console.WriteLine($"Read-only native scan completed: {devices.Count} Logitech device(s), {clock.ElapsedMilliseconds} ms");
    foreach (var device in devices) Console.WriteLine($"{device.Name}: {device.Percent}% {device.Status}");
}

namespace MousePower
{
    public record BatteryDevice(string Id, string Name, string Brand, string Connection, int? Percent, bool? Charging,
        string Status, string Source, DateTimeOffset? SampleTime = null)
    { public string? PhysicalId { get; init; } }
    public interface IBatteryProvider { string Name { get; } Task<IReadOnlyList<BatteryDevice>> ScanAsync(CancellationToken cancellationToken); }
}
