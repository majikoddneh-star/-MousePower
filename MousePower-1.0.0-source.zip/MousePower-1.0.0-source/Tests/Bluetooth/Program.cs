using System.Reflection;
using System.Runtime.InteropServices;
using MousePower;

int assertions = 0;
void Check(bool condition, string name)
{
    if (!condition) throw new Exception("FAIL: " + name);
    assertions++;
    Console.WriteLine("PASS: " + name);
}
var providerType = typeof(BluetoothProvider);
Type Nested(string name) => providerType.GetNestedType(name, BindingFlags.NonPublic)!;
Check(Marshal.SizeOf(Nested("GattUuid")) == 20, "BTH_LE_UUID native size 20");
Check(Marshal.SizeOf(Nested("GattCharacteristic")) == 36, "BTH_LE_GATT_CHARACTERISTIC native size 36");
Check(Marshal.OffsetOf(Nested("GattCharacteristic"), "Uuid").ToInt32() == 4, "Characteristic UUID offset 4");
Check(Marshal.OffsetOf(Nested("GattCharacteristic"), "IsReadable").ToInt32() == 29, "BOOLEAN IsReadable offset 29");
Check(Marshal.SizeOf(Nested("DevPropKey")) == 20, "DEVPROPKEY native size 20");
Check(Marshal.SizeOf(Nested("DeviceInfoData")) == (IntPtr.Size == 8 ? 32 : 28), "SP_DEVINFO_DATA native size");
Check(Marshal.SizeOf(Nested("InterfaceData")) == (IntPtr.Size == 8 ? 32 : 28), "SP_DEVICE_INTERFACE_DATA native size");
var infoType = Nested("DeviceInfoData");
var nodeType = Nested("DeviceNode");
object MakeNode(Guid classGuid, string hardware)
{
    object info = Activator.CreateInstance(infoType)!;
    infoType.GetField("ClassGuid")!.SetValue(info, classGuid);
    var ctor = nodeType.GetConstructors(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
        .Single(c => c.GetParameters().Length == 7);
    return ctor.Invoke(new object?[] { info, "BTHLE\\DEV_001122334455", "Device", hardware, "Generic", null, Guid.Empty });
}
var isMouse = providerType.GetMethod("IsMouse", BindingFlags.NonPublic | BindingFlags.Static)!;
bool Mouse(Guid cls, string hardware) => (bool)isMouse.Invoke(null, new[] { MakeNode(cls, hardware) })!;
Check(Mouse(new Guid("4d36e96f-e325-11ce-bfc1-08002be10318"), ""), "Mouse device class accepted");
Check(Mouse(Guid.Empty, "HID_DEVICE_UP:0001_U:0002"), "Standard HID mouse usage accepted");
Check(!Mouse(Guid.Empty, "HID_DEVICE_UP:0001_U:0006"), "Keyboard HID usage excluded");
Check(!Mouse(new Guid("4d36e96c-e325-11ce-bfc1-08002be10318"), "BTHENUM\\HEADSET"), "Headset excluded");
var uuidType = Nested("GattUuid");
object uuid = Activator.CreateInstance(uuidType)!;
uuidType.GetField("IsShort")!.SetValue(uuid, (byte)1);
uuidType.GetField("Short")!.SetValue(uuid, (ushort)0x2A19);
Check((bool)uuidType.GetMethod("Matches")!.Invoke(uuid, new object[] { (ushort)0x2A19 })!, "Short Battery Level UUID matches");
uuidType.GetField("IsShort")!.SetValue(uuid, (byte)0);
uuidType.GetField("Long")!.SetValue(uuid, new Guid("00002a19-0000-1000-8000-00805f9b34fb"));
Check((bool)uuidType.GetMethod("Matches")!.Invoke(uuid, new object[] { (ushort)0x2A19 })!, "Long Battery Level UUID matches");
var provider = new BluetoothProvider();
using var cancellation = new CancellationTokenSource();
cancellation.Cancel();
bool cancelled = false;
try { await provider.ScanAsync(cancellation.Token); }
catch (OperationCanceledException) { cancelled = true; }
Check(cancelled, "Pre-cancelled scan exits cleanly");
var watch = System.Diagnostics.Stopwatch.StartNew();
var devices = await provider.ScanAsync(CancellationToken.None);
Console.WriteLine($"Native Windows scan completed: {devices.Count} Bluetooth mice, {watch.ElapsedMilliseconds} ms.");
foreach (var device in devices)
    Console.WriteLine($"Mouse: {device.Name}, {device.Percent?.ToString() ?? "unknown"}%, {device.Connection}, {device.Status}, sample={device.SampleTime?.ToString("O") ?? "unknown"}");
Console.WriteLine($"ALL {assertions} checks passed.");

namespace MousePower
{
    public record BatteryDevice(string Id, string Name, string Brand, string Connection, int? Percent,
        bool? Charging, string Status, string Source, DateTimeOffset? SampleTime = null)
    { public string? PhysicalId { get; init; } }
    public interface IBatteryProvider
    { string Name { get; } Task<IReadOnlyList<BatteryDevice>> ScanAsync(CancellationToken cancellationToken); }
}
