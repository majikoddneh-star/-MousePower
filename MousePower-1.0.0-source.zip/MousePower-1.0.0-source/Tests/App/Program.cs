using System.Reflection;
using Microsoft.Win32;

namespace MousePower;

internal static class AppTests
{
    private static int checks;

    [STAThread]
    private static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        TestSettings();
        TestStartup();
        TestTrayIcons();
        TestWindow(args.FirstOrDefault());
        TestTrayLifecycle();
        Console.WriteLine($"PASS: {checks} application integration checks; settings and startup registry restored.");
    }

    private static void Check(bool condition, string name)
    {
        if (!condition) throw new InvalidOperationException("FAIL: " + name);
        checks++;
    }

    private static void TestSettings()
    {
        var directoryExisted = Directory.Exists(Settings.DataDirectory);
        var originals = new Dictionary<string, byte[]?>
        {
            [Settings.FilePath] = File.Exists(Settings.FilePath) ? File.ReadAllBytes(Settings.FilePath) : null,
            [Settings.FilePath + ".tmp"] = File.Exists(Settings.FilePath + ".tmp") ? File.ReadAllBytes(Settings.FilePath + ".tmp") : null
        };
        try
        {
            Directory.CreateDirectory(Settings.DataDirectory);
            File.WriteAllText(Settings.FilePath, "{broken json");
            var invalid = Settings.Read();
            Check(invalid.RefreshSeconds == 60 && invalid.LowBatteryThreshold == 20, "Invalid JSON falls back to defaults");
            File.WriteAllText(Settings.FilePath, "{\"RefreshSeconds\":-1,\"LowBatteryThreshold\":-100}");
            var low = Settings.Read();
            Check(low.RefreshSeconds == 60 && low.LowBatteryThreshold == 5, "Invalid interval and low threshold clamp");
            File.WriteAllText(Settings.FilePath, "{\"RefreshSeconds\":300,\"LowBatteryThreshold\":101}");
            var high = Settings.Read();
            Check(high.RefreshSeconds == 300 && high.LowBatteryThreshold == 50, "Valid interval and high threshold clamp");
            new Settings { PrimaryId = "integration-test", RefreshSeconds = 120, LowBatteryThreshold = 25, CloseToTray = false }.Save();
            var roundtrip = Settings.Read();
            Check(roundtrip.PrimaryId == "integration-test" && roundtrip.RefreshSeconds == 120 && roundtrip.LowBatteryThreshold == 25 && !roundtrip.CloseToTray,
                "Settings atomically save and reload");
        }
        finally
        {
            foreach (var pair in originals)
                if (pair.Value is null) File.Delete(pair.Key); else File.WriteAllBytes(pair.Key, pair.Value);
            if (!directoryExisted && !Directory.EnumerateFileSystemEntries(Settings.DataDirectory).Any()) Directory.Delete(Settings.DataDirectory);
        }
        Check(originals.All(pair => pair.Value is null ? !File.Exists(pair.Key) : File.ReadAllBytes(pair.Key).SequenceEqual(pair.Value)),
            "Settings and temporary file restored byte-for-byte");
    }

    private static void TestStartup()
    {
        const string keyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
        using var key = Registry.CurrentUser.CreateSubKey(keyPath);
        bool existed = key.GetValueNames().Contains("MousePower", StringComparer.OrdinalIgnoreCase);
        object? original = existed ? key.GetValue("MousePower", null, RegistryValueOptions.DoNotExpandEnvironmentNames) : null;
        var originalKind = existed ? key.GetValueKind("MousePower") : RegistryValueKind.String;
        try
        {
            Startup.Set(false);
            Check(!Startup.Enabled, "Disabling startup removes the app value");
            Startup.Set(true);
            Check(Startup.Enabled, "Startup option round-trips");
            Check((string?)key.GetValue("MousePower") == "\"" + Environment.ProcessPath + "\" --background", "Startup uses quoted executable path and background flag");
        }
        finally
        {
            if (existed) key.SetValue("MousePower", original!, originalKind); else key.DeleteValue("MousePower", false);
        }
        Check(existed
            ? Equals(key.GetValue("MousePower", null, RegistryValueOptions.DoNotExpandEnvironmentNames), original) && key.GetValueKind("MousePower") == originalKind
            : !key.GetValueNames().Contains("MousePower", StringComparer.OrdinalIgnoreCase), "Startup registry value and kind restored");
    }

    private static void TestTrayIcons()
    {
        var hashes = new HashSet<string>();
        foreach (int? percent in new int?[] { 0, 20, 100, null })
        {
            using var icon = TrayArtwork.Make(percent, false);
            Check(icon.Width == 64 && icon.Height == 64 && icon.Handle != IntPtr.Zero, $"Tray icon renders {percent?.ToString() ?? "unknown"}");
            using var bitmap = icon.ToBitmap();
            using var bytes = new MemoryStream();
            bitmap.Save(bytes, System.Drawing.Imaging.ImageFormat.Png);
            hashes.Add(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes.ToArray())));
        }
        Check(hashes.Count == 4, "Zero, low, full and unknown icons are visually distinct");
        using var normal = TrayArtwork.Make(72, false);
        using var charging = TrayArtwork.Make(72, true);
        using var normalBitmap = normal.ToBitmap();
        using var chargingBitmap = charging.ToBitmap();
        Check(normalBitmap.GetPixel(30, 58) != chargingBitmap.GetPixel(30, 58), "Charging changes the battery indicator color");
    }

    private static T Field<T>(object instance, string name) =>
        (T)instance.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(instance)!;

    private static void TestTrayLifecycle()
    {
        bool directoryExisted = Directory.Exists(Settings.DataDirectory);
        var originals = new Dictionary<string, byte[]?>
        {
            [Settings.FilePath] = File.Exists(Settings.FilePath) ? File.ReadAllBytes(Settings.FilePath) : null,
            [Settings.FilePath + ".tmp"] = File.Exists(Settings.FilePath + ".tmp") ? File.ReadAllBytes(Settings.FilePath + ".tmp") : null
        };
        try
        {
            // Enable the behavior under test and avoid notifications from a real
            // connected device. Restore the user's exact preferences afterward.
            new Settings { CloseToTray = true, LowBatteryAlerts = false, RefreshSeconds = 300 }.Save();
            using var activation = new EventWaitHandle(false, EventResetMode.AutoReset);
            using var context = new PowerContext(new[] { "--background" }, activation);
            using var timer = new System.Windows.Forms.Timer { Interval = 100 };
            var window = Field<MainForm>(context, "window");
            var tray = Field<NotifyIcon>(context, "tray");
            var quit = typeof(PowerContext).GetMethod("Quit", BindingFlags.NonPublic | BindingFlags.Instance)!;
            var clock = System.Diagnostics.Stopwatch.StartNew();
            Exception? failure = null;
            int phase = 0;
            long signalAt = 0;
            timer.Tick += (_, _) =>
            {
                try
                {
                    if (clock.Elapsed > TimeSpan.FromSeconds(10)) throw new TimeoutException("Tray lifecycle loop did not finish");
                    if (phase == 0)
                    {
                        // Let the initial real, read-only scanner finish, while
                        // still bounding this UI lifecycle test to five seconds.
                        var firstScan = Field<ScanResult?>(context, "latest");
                        if (firstScan is null && clock.Elapsed < TimeSpan.FromSeconds(5)) return;
                        Console.WriteLine($"Lifecycle initial scan completed: {firstScan is not null}, elapsed={clock.ElapsedMilliseconds} ms");
                        Check(tray.Visible, "Background launch creates visible tray icon");
                        Check(!window.Visible, "Background launch keeps its window hidden");
                        activation.Set();
                        signalAt = clock.ElapsedMilliseconds;
                        phase = 1;
                    }
                    else if (phase == 1)
                    {
                        if (!window.Visible)
                        {
                            if (clock.ElapsedMilliseconds - signalAt > 2500) throw new TimeoutException("Activation signal failed to show the window");
                            return;
                        }
                        Check(window.Visible, "Activation event opens the existing window");
                        window.Close();
                        Check(!window.Visible && !window.IsDisposed, "Closing to tray hides and preserves the window");
                        Check(tray.Visible, "Closing the window preserves its tray icon");
                        phase = 2;
                        timer.Stop();
                        quit.Invoke(context, null);
                        Check(!tray.Visible, "Quit removes the tray icon");
                    }
                }
                catch (Exception ex)
                {
                    failure = ex;
                    timer.Stop();
                    try { quit.Invoke(context, null); } catch { context.ExitThread(); }
                }
            };
            timer.Start();
            Application.Run(context);
            timer.Stop();
            if (failure is not null) throw new InvalidOperationException("Tray lifecycle integration failed", failure);
            Check(phase == 2 && Field<bool>(context, "quitting"), "Quit exits the actual application message loop");
        }
        finally
        {
            foreach (var pair in originals)
                if (pair.Value is null) File.Delete(pair.Key); else File.WriteAllBytes(pair.Key, pair.Value);
            if (!directoryExisted && !Directory.EnumerateFileSystemEntries(Settings.DataDirectory).Any()) Directory.Delete(Settings.DataDirectory);
        }
        Check(originals.All(pair => pair.Value is null ? !File.Exists(pair.Key) : File.ReadAllBytes(pair.Key).SequenceEqual(pair.Value)),
            "Lifecycle test restores original settings byte-for-byte");
    }

    private static void TestWindow(string? screenshotPath)
    {
        using var form = new MainForm(new Settings());
        form.Show();
        Application.DoEvents();
        var empty = new ScanResult(DateTimeOffset.Now, Array.Empty<BatteryDevice>(), Array.Empty<string>());
        form.Render(empty, null);
        Check(Field<Label>(form, "heroPercent").Text == "—" && Field<DataGridView>(form, "grid").Rows.Count == 0,
            "Empty result renders unknown without phantom devices");
        Check(Field<ProgressBar>(form, "batteryBar").Value == 0, "Empty result clears battery bar");

        var sample = new BatteryDevice("test:mouse", "测试罗技鼠标", "罗技", "2.4 GHz 接收器", 72, false, "使用电池", "HID++ 0x1004", DateTimeOffset.Now);
        var coarse = new BatteryDevice("test:band", "测试鼠标（仅电量档位）", "通用", "蓝牙", null, false, "电量良好（设备只提供档位）", "测试数据");
        var result = new ScanResult(DateTimeOffset.Now, new[] { sample, coarse }, Array.Empty<string>());
        form.Render(result, sample);
        Application.DoEvents();
        var grid = Field<DataGridView>(form, "grid");
        Check(Field<Label>(form, "heroPercent").Text == "72%" && Field<ProgressBar>(form, "batteryBar").Value == 72,
            "Measured battery renders percentage and progress");
        Check(grid.Rows.Count == 2 && (string)grid.Rows[1].Cells[2].Value! == "未知", "Unmeasured device stays unknown in grid");
        Check(Field<ComboBox>(form, "primary").Items.Count == 2 && Field<ComboBox>(form, "primary").SelectedIndex == 0,
            "Tray selector follows the chosen device");
        Check(Field<Label>(form, "detail").Text.Contains("HID++ 0x1004"), "Selected device details show data source");
        Check(grid.ClientSize.Width > 500 && grid.ClientSize.Height > 100 && grid.Columns.Cast<DataGridViewColumn>().All(column => column.Width >= 60),
            "Device list has usable layout dimensions");
        form.Size = form.MinimumSize;
        Application.DoEvents();
        Check(grid.ClientSize.Height > 70 && Field<ComboBox>(form, "primary").Width > 200, "Minimum window size keeps controls usable");
        form.Size = new Size(920, 740);
        Application.DoEvents();
        if (!string.IsNullOrWhiteSpace(screenshotPath))
        {
            var fullPath = Path.GetFullPath(screenshotPath);
            Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);
            using var bitmap = new Bitmap(form.Width, form.Height);
            form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size));
            bitmap.Save(fullPath, System.Drawing.Imaging.ImageFormat.Png);
            Console.WriteLine("Fixture layout screenshot: " + fullPath);
        }
        form.Close();
    }
}
