using System.Text.Json;

namespace MousePower;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        string? diagnostic = args.FirstOrDefault(a => a.StartsWith("--diagnose="))?.Substring(11);
        if (diagnostic != null)
        {
            try
            {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(45));
                var result = new BatteryScanner().ScanAsync(timeout.Token).GetAwaiter().GetResult();
                File.WriteAllText(Path.GetFullPath(diagnostic), JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch (Exception ex) { File.WriteAllText(Path.GetFullPath(diagnostic), JsonSerializer.Serialize(new { Error = ex.ToString() })); Environment.ExitCode = 1; }
            return;
        }
        using var mutex = new Mutex(true, @"Local\MousePower.UserInstance", out bool isFirst);
        using var showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, @"Local\MousePower.ShowWindow");
        if (!isFirst) { showEvent.Set(); return; }
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) => MessageBox.Show("程序遇到错误：" + e.Exception.Message, "鼠标电量", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        using var context = new PowerContext(args, showEvent);
        Application.Run(context);
    }
}

internal sealed class PowerContext : ApplicationContext
{
    private readonly Settings settings = Settings.Read();
    private readonly BatteryScanner scanner = new();
    private readonly NotifyIcon tray = new();
    private readonly System.Windows.Forms.Timer poll = new();
    private readonly System.Windows.Forms.Timer activation = new() { Interval = 400 };
    private readonly CancellationTokenSource shutdown = new();
    private readonly MainForm window;
    private readonly EventWaitHandle showEvent;
    private readonly HashSet<string> notified = new();
    private ScanResult? latest;
    private Icon? currentIcon;
    private bool scanning, quitting;
    private readonly string? screenshot;

    public PowerContext(string[] args, EventWaitHandle showEvent)
    {
        this.showEvent = showEvent;
        screenshot = args.FirstOrDefault(a => a.StartsWith("--screenshot="))?.Substring(13);
        window = new MainForm(settings);
        window.RefreshRequested += async (_, _) => await RefreshAsync();
        window.PrimaryChanged += (_, id) => { settings.PrimaryId = id; SaveSettings(); UpdateTray(); window.Render(latest, Primary); };
        window.SettingsChanged += (_, _) => { SaveSettings(); poll.Interval = settings.RefreshSeconds * 1000; };
        window.FormClosing += (_, e) =>
        {
            if (!quitting && settings.CloseToTray && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; window.Hide(); }
            else if (!quitting) { e.Cancel = true; Quit(); }
        };
        tray.Text = "鼠标电量 · 正在检测";
        currentIcon = TrayArtwork.Make(null, null);
        tray.Icon = currentIcon;
        tray.Visible = true;
        tray.MouseClick += (_, e) => { if (e.Button == MouseButtons.Left) ShowWindow(); };
        tray.ContextMenuStrip = BuildMenu();
        activation.Tick += (_, _) => { if (showEvent.WaitOne(0)) ShowWindow(); };
        activation.Start();
        poll.Interval = settings.RefreshSeconds * 1000;
        poll.Tick += async (_, _) => await RefreshAsync();
        poll.Start();
        if (!args.Contains("--background")) ShowWindow();
        _ = RefreshAsync();
    }

    private BatteryDevice? Primary => latest?.Devices.FirstOrDefault(d => d.Id == settings.PrimaryId)
        ?? latest?.Devices.FirstOrDefault(d => d.Percent.HasValue) ?? latest?.Devices.FirstOrDefault();

    private void SaveSettings()
    {
        try { settings.Save(); }
        catch (Exception ex) { window.SetStatus("设置未保存：" + ex.Message); }
    }

    private void ShowWindow() { window.Show(); if (window.WindowState == FormWindowState.Minimized) window.WindowState = FormWindowState.Normal; window.Activate(); }

    private async Task RefreshAsync()
    {
        if (scanning || quitting) return;
        scanning = true;
        window.SetBusy(true);
        try
        {
            latest = await Task.Run(() => scanner.ScanAsync(shutdown.Token), shutdown.Token);
            if (quitting) return;
            window.Render(latest, Primary);
            UpdateTray();
            foreach (var device in latest.Devices)
            {
                if (device.Percent is int value && value > settings.LowBatteryThreshold + 5) notified.Remove(device.Id);
                if (settings.LowBatteryAlerts && device.SampleTime.HasValue && device.Percent is int percent && percent <= settings.LowBatteryThreshold && device.Charging != true && notified.Add(device.Id))
                    tray.ShowBalloonTip(6000, "鼠标电量偏低", $"{device.Name}：{percent}%\n请及时充电或更换电池。", ToolTipIcon.Warning);
            }
            if (screenshot != null)
            {
                window.SetBusy(false);
                ShowWindow();
                await Task.Delay(800);
                using var bitmap = new Bitmap(window.Width, window.Height);
                window.DrawToBitmap(bitmap, window.ClientRectangle with { Width = window.Width, Height = window.Height });
                bitmap.Save(Path.GetFullPath(screenshot), System.Drawing.Imaging.ImageFormat.Png);
                Quit();
            }
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { if (!quitting) window.SetStatus("读取失败：" + ex.Message); }
        finally { scanning = false; if (!quitting) window.SetBusy(false); }
    }

    private void UpdateTray()
    {
        var selected = Primary;
        var next = TrayArtwork.Make(selected?.Percent, selected?.Charging);
        tray.Icon = next;
        currentIcon?.Dispose();
        currentIcon = next;
        string text = selected == null ? "鼠标电量 · 未检测到可读取的鼠标" : $"{selected.Name} · {(selected.Percent.HasValue ? selected.Percent + "%" : "电量未知")}\n{selected.Connection}";
        tray.Text = text.Length <= 127 ? text : text[..127];
        var oldMenu = tray.ContextMenuStrip;
        tray.ContextMenuStrip = BuildMenu();
        oldMenu?.Dispose();
    }

    private ContextMenuStrip BuildMenu()
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("打开鼠标电量", null, (_, _) => ShowWindow());
        menu.Items.Add("立即刷新", null, async (_, _) => await RefreshAsync());
        if (latest?.Devices.Count > 0)
        {
            var devices = new ToolStripMenuItem("托盘显示的设备");
            foreach (var device in latest.Devices)
            {
                var item = new ToolStripMenuItem(device.Name + (device.Percent.HasValue ? $" · {device.Percent}%" : " · 未知")) { Checked = device.Id == Primary?.Id };
                item.Click += (_, _) => { settings.PrimaryId = device.Id; SaveSettings(); window.Render(latest, Primary); UpdateTray(); };
                devices.DropDownItems.Add(item);
            }
            menu.Items.Add(devices);
        }
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("退出", null, (_, _) => Quit());
        return menu;
    }

    private void Quit()
    {
        if (quitting) return;
        quitting = true;
        shutdown.Cancel();
        poll.Stop(); activation.Stop();
        tray.Visible = false;
        window.Close();
        ExitThread();
    }

    protected override void Dispose(bool disposing)
    {
        // A provider can still be draining cancelled native I/O when the UI loop
        // exits. Keep the token's wait handle alive until process teardown.
        if (disposing) { shutdown.Cancel(); tray.Dispose(); currentIcon?.Dispose(); poll.Dispose(); activation.Dispose(); window.Dispose(); }
        base.Dispose(disposing);
    }
}
