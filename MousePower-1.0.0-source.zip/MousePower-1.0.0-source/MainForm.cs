using System.Text.Json;

namespace MousePower;

internal sealed class MainForm : Form
{
    private readonly Settings settings;
    private readonly Label heroName = new(), heroPercent = new(), heroDetail = new(), footer = new();
    private readonly ProgressBar batteryBar = new();
    private readonly DataGridView grid = new();
    private readonly Button refresh = new();
    private readonly ComboBox primary = new();
    private readonly Label detail = new();
    private ScanResult? result;
    private bool rendering;
    public event EventHandler? RefreshRequested, SettingsChanged;
    public event EventHandler<string>? PrimaryChanged;
    private static readonly Color Ink = Color.FromArgb(28, 36, 58);
    private static readonly Color Muted = Color.FromArgb(102, 113, 136);

    public MainForm(Settings settings)
    {
        this.settings = settings;
        Text = "鼠标电量 · MousePower";
        Font = new Font("Microsoft YaHei UI", 9F);
        BackColor = Color.FromArgb(246, 248, 252);
        ForeColor = Ink;
        Size = new Size(920, 740);
        MinimumSize = new Size(790, 650);
        StartPosition = FormStartPosition.CenterScreen;
        AutoScaleMode = AutoScaleMode.Dpi;
        using (var ownIcon = Icon.ExtractAssociatedIcon(Environment.ProcessPath!)) if (ownIcon != null) Icon = (Icon)ownIcon.Clone();

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(25, 20, 25, 12), ColumnCount = 1, RowCount = 4 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 145));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
        Controls.Add(root);

        var header = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, Margin = Padding.Empty };
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112));
        var title = new Label { Text = "鼠标电量", Font = new Font(Font.FontFamily, 21, FontStyle.Bold), AutoSize = true, Dock = DockStyle.Left, Margin = Padding.Empty };
        refresh.Text = "立即刷新"; refresh.Dock = DockStyle.Top; refresh.Height = 36; refresh.FlatStyle = FlatStyle.Flat;
        refresh.BackColor = TrayArtwork.Accent; refresh.ForeColor = Color.White; refresh.FlatAppearance.BorderSize = 0;
        refresh.Click += (_, _) => RefreshRequested?.Invoke(this, EventArgs.Empty);
        header.Controls.Add(title, 0, 0); header.Controls.Add(refresh, 1, 0); root.Controls.Add(header, 0, 0);

        var hero = new TableLayoutPanel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(20, 14, 20, 12), ColumnCount = 2, RowCount = 3, Margin = new Padding(0, 0, 0, 17) };
        hero.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); hero.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160));
        hero.RowStyles.Add(new RowStyle(SizeType.Absolute, 36)); hero.RowStyles.Add(new RowStyle(SizeType.Absolute, 33)); hero.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        heroName.Text = "正在查找鼠标…"; heroName.Font = new Font(Font.FontFamily, 14, FontStyle.Bold); heroName.Dock = DockStyle.Fill; heroName.AutoEllipsis = true;
        heroPercent.Text = "—"; heroPercent.ForeColor = TrayArtwork.Accent; heroPercent.Font = new Font("Segoe UI", 34, FontStyle.Bold); heroPercent.Dock = DockStyle.Fill; heroPercent.TextAlign = ContentAlignment.MiddleRight;
        heroDetail.Text = "读取设备提供的电量信息"; heroDetail.ForeColor = Muted; heroDetail.Dock = DockStyle.Fill;
        batteryBar.Dock = DockStyle.Top; batteryBar.Height = 8; batteryBar.Style = ProgressBarStyle.Continuous;
        hero.Controls.Add(heroName, 0, 0); hero.Controls.Add(heroDetail, 0, 1); hero.Controls.Add(batteryBar, 0, 2); hero.Controls.Add(heroPercent, 1, 0); hero.SetRowSpan(heroPercent, 3);
        root.Controls.Add(hero, 0, 1);

        var tabs = new TabControl { Dock = DockStyle.Fill, Padding = new Point(17, 7), Margin = Padding.Empty };
        var devicesTab = new TabPage("设备") { BackColor = Color.White, Padding = new Padding(14) };
        var settingsTab = new TabPage("设置") { BackColor = Color.White, Padding = new Padding(18) };
        var helpTab = new TabPage("兼容与帮助") { BackColor = Color.White, Padding = new Padding(18) };
        tabs.TabPages.AddRange(new[] { devicesTab, settingsTab, helpTab }); root.Controls.Add(tabs, 0, 2);

        var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, 38)); body.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); body.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
        var selector = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
        selector.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110)); selector.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        selector.Controls.Add(new Label { Text = "托盘显示设备", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        primary.DropDownStyle = ComboBoxStyle.DropDownList; primary.Dock = DockStyle.Fill;
        primary.SelectedIndexChanged += (_, _) => { if (!rendering && primary.SelectedItem is Choice choice) PrimaryChanged?.Invoke(this, choice.Id); };
        selector.Controls.Add(primary, 1, 0); body.Controls.Add(selector, 0, 0);
        grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.AllowUserToAddRows = false; grid.AllowUserToDeleteRows = false; grid.AllowUserToResizeRows = false;
        grid.RowHeadersVisible = false; grid.MultiSelect = false; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.AutoGenerateColumns = false;
        grid.BackgroundColor = Color.White; grid.BorderStyle = BorderStyle.None; grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        grid.GridColor = Color.FromArgb(235, 238, 245); grid.EnableHeadersVisualStyles = false;
        grid.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(246, 248, 252), ForeColor = Muted, Font = new Font(Font, FontStyle.Regular) };
        grid.ColumnHeadersHeight = 34; grid.RowTemplate.Height = 43;
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(232, 236, 255); grid.DefaultCellStyle.SelectionForeColor = Ink;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "设备", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, FillWeight = 35 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "连接", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, FillWeight = 20 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "电量", Width = 75 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "状态", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, FillWeight = 45 });
        grid.SelectionChanged += (_, _) => UpdateDetail();
        body.Controls.Add(grid, 0, 1); detail.Dock = DockStyle.Fill; detail.ForeColor = Muted; detail.Padding = new Padding(0, 8, 0, 0); body.Controls.Add(detail, 0, 2);
        devicesTab.Controls.Add(body);
        BuildSettings(settingsTab); BuildHelp(helpTab);
        footer.Text = "首次检测中…"; footer.ForeColor = Muted; footer.Dock = DockStyle.Fill; footer.TextAlign = ContentAlignment.MiddleLeft;
        root.Controls.Add(footer, 0, 3);
    }

    private void BuildSettings(TabPage tab)
    {
        var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true };
        tab.Controls.Add(flow);
        var startup = new CheckBox { Text = "开机自启（仅当前 Windows 用户）", AutoSize = true, Margin = new Padding(0, 5, 0, 16) };
        try { startup.Checked = Startup.Enabled; } catch { }
        startup.CheckedChanged += (_, _) =>
        {
            try { Startup.Set(startup.Checked); }
            catch (Exception ex) { MessageBox.Show("无法修改开机自启：" + ex.Message, Text); }
        };
        flow.Controls.Add(startup);
        var close = new CheckBox { Text = "关闭窗口时继续在托盘运行", Checked = settings.CloseToTray, AutoSize = true, Margin = new Padding(0, 0, 0, 16) };
        close.CheckedChanged += (_, _) => { settings.CloseToTray = close.Checked; SettingsChanged?.Invoke(this, EventArgs.Empty); }; flow.Controls.Add(close);
        var alerts = new CheckBox { Text = "低电量提醒（仅设备直读时）", Checked = settings.LowBatteryAlerts, AutoSize = true, Margin = new Padding(0, 0, 0, 10) };
        alerts.CheckedChanged += (_, _) => { settings.LowBatteryAlerts = alerts.Checked; SettingsChanged?.Invoke(this, EventArgs.Empty); }; flow.Controls.Add(alerts);
        var threshold = new NumericUpDown { Minimum = 5, Maximum = 50, Value = settings.LowBatteryThreshold, Width = 100 };
        flow.Controls.Add(new Label { Text = "提醒阈值（%）", AutoSize = true }); flow.Controls.Add(threshold);
        threshold.ValueChanged += (_, _) => { settings.LowBatteryThreshold = (int)threshold.Value; SettingsChanged?.Invoke(this, EventArgs.Empty); };
        flow.Controls.Add(new Label { Text = "自动刷新间隔", AutoSize = true, Margin = new Padding(0, 17, 0, 5) });
        var interval = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 160 };
        foreach (int seconds in new[] { 30, 60, 120, 300 }) interval.Items.Add(new IntervalChoice(seconds));
        interval.SelectedItem = interval.Items.Cast<IntervalChoice>().First(x => x.Seconds == settings.RefreshSeconds);
        interval.SelectedIndexChanged += (_, _) => { if (interval.SelectedItem is IntervalChoice item) { settings.RefreshSeconds = item.Seconds; SettingsChanged?.Invoke(this, EventArgs.Empty); } }; flow.Controls.Add(interval);
        var export = new Button { Text = "导出诊断信息…", AutoSize = true, Padding = new Padding(8, 5, 8, 5), Margin = new Padding(0, 20, 0, 0) };
        export.Click += (_, _) => ExportDiagnostic(); flow.Controls.Add(export);
    }

    private void BuildHelp(TabPage tab)
    {
        var text = new TextBox { Multiline = true, ReadOnly = true, BorderStyle = BorderStyle.None, BackColor = Color.White, Dock = DockStyle.Fill, ScrollBars = ScrollBars.Vertical, Font = Font,
            Text = "让电量常驻托盘\r\n单击托盘图标打开窗口，右键可刷新、切换设备或退出。Windows 可能将图标收进 ^ 菜单，可把它拖到系统电量图标附近。系统决定图标顺序，本软件不会替换电脑电池图标。\r\n\r\n连接方式与兼容范围\r\n• 雷蛇：按 USB 产品 ID 和专有电量协议识别，覆盖 Orochi V2、Viper、DeathAdder、Basilisk、Naga 等系列的已收录型号。2.4G 接收器与蓝牙使用不同接口。\r\n• 罗技：通过 HID++ 动态查找电量功能，覆盖提供相应功能的 Unifying、Bolt、LIGHTSPEED、直连设备。部分型号只报告电量档位。\r\n• 其他品牌蓝牙鼠标：设备和驱动向 Windows 提供电量，或提供标准 GATT 电量服务时可读取。\r\n• 其他品牌 2.4G：各家协议不同，本版本未提供专有适配。不能保证所有无线鼠标都能读取。\r\n\r\n读数说明\r\n电量由鼠标固件估算，更换电池的鼠标可能长时间保持同一读数。Windows 提供的电量属性可能是缓存，应用会注明来源。没有有效数据时显示“未知”，不会编造百分比。\r\n\r\n读取不到时\r\n移动鼠标唤醒后点击刷新；检查接收器或蓝牙连接。部分驱动、厂商软件独占接口或固件版本会影响读取。导出的诊断文件仅保存在你选定的位置，分享前可自行检查。\r\n\r\n隐私\r\n软件在本机读取设备数据，不上传、不联网更新、不安装内核驱动。开机自启默认关闭，可在设置中启用。\r\n\r\nMousePower 1.0.0 · Windows 10/11 x64\r\n协议来源、完整源码与构建方法见随附说明。" };
        tab.Controls.Add(text);
    }

    public void SetBusy(bool busy) { refresh.Enabled = !busy; refresh.Text = busy ? "正在读取…" : "立即刷新"; if (busy) footer.Text = "正在读取电量，首次探测可能需要几秒…"; }
    public void SetStatus(string text) => footer.Text = text;

    public void Render(ScanResult? data, BatteryDevice? selected)
    {
        if (data == null) return;
        result = data; rendering = true;
        try
        {
            heroName.Text = selected?.Name ?? "未检测到可读取的鼠标";
            heroPercent.Text = selected?.Percent is int value ? $"{value}%" : "—";
            heroDetail.Text = selected == null ? "唤醒鼠标或检查连接后，再点击刷新" : $"{selected.Brand}  ·  {selected.Connection}  ·  {(selected.Charging == true ? "正在充电" : selected.Percent.HasValue ? "设备电量" : "电量未知")}";
            batteryBar.Value = selected?.Percent ?? 0;
            primary.Items.Clear(); grid.Rows.Clear();
            foreach (var device in data.Devices)
            {
                var choice = new Choice(device.Id, device.Name); primary.Items.Add(choice);
                if (device.Id == selected?.Id) primary.SelectedItem = choice;
                int row = grid.Rows.Add(device.Name, device.Connection, device.Percent.HasValue ? device.Percent + "%" : "未知", device.Status);
                grid.Rows[row].Tag = device;
                if (device.Id == selected?.Id) { grid.ClearSelection(); grid.Rows[row].Selected = true; }
            }
            footer.Text = $"更新于 {data.CompletedAt:HH:mm:ss}  ·  {data.Devices.Count} 个设备  ·  每 {settings.RefreshSeconds} 秒刷新";
            if (data.Messages.Count > 0) footer.Text += "  ·  部分通道读取失败（可导出诊断）";
            UpdateDetail();
        }
        finally { rendering = false; }
    }

    private void UpdateDetail()
    {
        if (grid.SelectedRows.Count > 0 && grid.SelectedRows[0].Tag is BatteryDevice device)
            detail.Text = $"{device.Source}\r\n{(device.SampleTime.HasValue ? "采样时间：" + device.SampleTime.Value.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss") : "采样时间未知；可能为 Windows 缓存或未取得有效读数")}\r\n{device.Status}";
        else detail.Text = "未发现设备时，请检查连接并移动鼠标唤醒。其他品牌的 2.4G 专有协议需要单独适配。";
    }

    private void ExportDiagnostic()
    {
        using var dialog = new SaveFileDialog { Filter = "JSON 诊断文件|*.json", FileName = "MousePower-diagnostic.json" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try { File.WriteAllText(dialog.FileName, JsonSerializer.Serialize(new { Version = "1.0.0", OS = Environment.OSVersion.ToString(), Result = result }, new JsonSerializerOptions { WriteIndented = true })); SetStatus("诊断信息已保存。文件包含设备名称和设备标识，分享前可先检查。"); }
        catch (Exception ex) { MessageBox.Show("保存失败：" + ex.Message, Text); }
    }

    private sealed record Choice(string Id, string Name) { public override string ToString() => Name; }
    private sealed record IntervalChoice(int Seconds) { public override string ToString() => Seconds < 60 ? Seconds + " 秒" : (Seconds / 60) + " 分钟"; }
}
