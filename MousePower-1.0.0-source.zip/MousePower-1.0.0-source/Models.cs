using System.Text.Json;
using Microsoft.Win32;

namespace MousePower;

public record BatteryDevice(string Id, string Name, string Brand, string Connection,
    int? Percent, bool? Charging, string Status, string Source, DateTimeOffset? SampleTime = null)
{
    public string? PhysicalId { get; init; }
}

public interface IBatteryProvider
{
    string Name { get; }
    Task<IReadOnlyList<BatteryDevice>> ScanAsync(CancellationToken cancellationToken);
}

public sealed class Settings
{
    public string? PrimaryId { get; set; }
    public int RefreshSeconds { get; set; } = 60;
    public bool LowBatteryAlerts { get; set; } = true;
    public int LowBatteryThreshold { get; set; } = 20;
    public bool CloseToTray { get; set; } = true;
    public static string DataDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MousePower");
    public static string FilePath => Path.Combine(DataDirectory, "settings.json");
    public static Settings Read()
    {
        try
        {
            var s = JsonSerializer.Deserialize<Settings>(File.ReadAllText(FilePath)) ?? new Settings();
            if (!new[] { 30, 60, 120, 300 }.Contains(s.RefreshSeconds)) s.RefreshSeconds = 60;
            s.LowBatteryThreshold = Math.Clamp(s.LowBatteryThreshold, 5, 50);
            return s;
        }
        catch { return new Settings(); }
    }
    public void Save()
    {
        Directory.CreateDirectory(DataDirectory);
        string temporary = FilePath + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(temporary, FilePath, true);
    }
}

public static class Startup
{
    private const string KeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    public static bool Enabled
    {
        get { using var key = Registry.CurrentUser.OpenSubKey(KeyPath); return key?.GetValue("MousePower") is string; }
    }
    public static void Set(bool enabled)
    {
        using var key = Registry.CurrentUser.CreateSubKey(KeyPath);
        if (enabled) key.SetValue("MousePower", "\"" + Environment.ProcessPath + "\" --background");
        else key.DeleteValue("MousePower", false);
    }
}

public sealed record ScanResult(DateTimeOffset CompletedAt, IReadOnlyList<BatteryDevice> Devices, IReadOnlyList<string> Messages);

public sealed class BatteryScanner
{
    private readonly IBatteryProvider[] providers = { new RazerProvider(), new LogitechProvider(), new BluetoothProvider() };
    public async Task<ScanResult> ScanAsync(CancellationToken cancellationToken)
    {
        var tasks = providers.Select(async provider =>
        {
            try { return (Devices: await provider.ScanAsync(cancellationToken), Error: (string?)null); }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
            catch (Exception ex) { return (Devices: (IReadOnlyList<BatteryDevice>)Array.Empty<BatteryDevice>(), Error: provider.Name + ": " + ex.Message); }
        });
        var results = await Task.WhenAll(tasks);
        var devices = results.SelectMany(r => r.Devices)
            .Select(d => d.Percent is < 0 or > 100 ? d with { Percent = null, Status = "设备返回的电量值无效" } : d)
            .GroupBy(d => d.PhysicalId ?? d.Id, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.OrderByDescending(d => d.Percent.HasValue).ThenByDescending(d => d.SampleTime.HasValue).First())
            .OrderByDescending(d => d.Percent.HasValue).ThenBy(d => d.Name).ToArray();
        return new ScanResult(DateTimeOffset.Now, devices, results.Where(r => r.Error != null).Select(r => r.Error!).ToArray());
    }
}
