#ifndef PublishDir
  #define PublishDir "publish"
#endif
#ifndef OutputDir
  #define OutputDir "dist"
#endif
[Setup]
AppId={{13B67DD1-0D2C-4429-A9CE-C3C720A1A2FA}
AppName=鼠标电量 MousePower
AppVersion=1.0.0
AppPublisher=MousePower
DefaultDirName={localappdata}\Programs\MousePower
DefaultGroupName=鼠标电量 MousePower
DisableProgramGroupPage=yes
DisableDirPage=no
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.19041
OutputDir={#OutputDir}
OutputBaseFilename=MousePower-1.0.0-Setup-x64
SetupIconFile=Assets\MousePower.ico
UninstallDisplayIcon={app}\MousePower.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
AppMutex=Local\MousePower.UserInstance
LicenseFile=LICENSE.txt
InfoAfterFile=INSTALL-NOTES.txt
VersionInfoVersion=1.0.0.0

[Languages]
Name: "chinesesimplified"; MessagesFile: "Assets\ChineseSimplified.isl"

[Tasks]
Name: "desktopicon"; Description: "创建桌面快捷方式"; Flags: unchecked
Name: "startup"; Description: "开机自动运行（可在软件设置中修改）"; Flags: unchecked

[Files]
Source: "{#PublishDir}\MousePower.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "THIRD_PARTY_NOTICES.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "DOTNET-LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "DOTNET-THIRD-PARTY-NOTICES.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\鼠标电量"; Filename: "{app}\MousePower.exe"
Name: "{autodesktop}\鼠标电量"; Filename: "{app}\MousePower.exe"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "MousePower"; ValueData: """{app}\MousePower.exe"" --background"; Tasks: startup; Flags: uninsdeletevalue

[UninstallDelete]
Type: files; Name: "{localappdata}\MousePower\settings.json"
Type: files; Name: "{localappdata}\MousePower\settings.json.tmp"
Type: dirifempty; Name: "{localappdata}\MousePower"

[Run]
Filename: "{app}\MousePower.exe"; Description: "启动鼠标电量"; Flags: nowait postinstall skipifsilent

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usUninstall then
    RegDeleteValue(HKCU, 'Software\Microsoft\Windows\CurrentVersion\Run', 'MousePower');
end;
