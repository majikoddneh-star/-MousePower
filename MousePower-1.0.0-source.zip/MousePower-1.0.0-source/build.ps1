param([string]$Dotnet = 'dotnet', [string]$Iscc = 'ISCC.exe')
$ErrorActionPreference = 'Stop'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$projectRoot = $PSScriptRoot
$publishPath = Join-Path $projectRoot 'publish'
$distPath = Join-Path $projectRoot 'dist'
New-Item -ItemType Directory -Path $distPath -Force | Out-Null
foreach ($testProject in Get-ChildItem (Join-Path $projectRoot 'Tests') -Filter '*.csproj' -Recurse) {
    & $Dotnet run --project $testProject.FullName -c Release
    if ($LASTEXITCODE -ne 0) { throw "Tests failed: $($testProject.Name)" }
}
& $Dotnet publish (Join-Path $projectRoot 'MousePower.csproj') -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -o $publishPath
if ($LASTEXITCODE -ne 0) { throw 'Publish failed' }
& $Iscc "/DPublishDir=$publishPath" "/DOutputDir=$distPath" (Join-Path $projectRoot 'installer.iss')
if ($LASTEXITCODE -ne 0) { throw 'Installer build failed' }
Write-Host "Build complete: $distPath"
