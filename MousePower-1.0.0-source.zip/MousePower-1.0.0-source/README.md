# 鼠标电量 MousePower 1.0.0

Windows 10 2004 及更新版本 / Windows 11，x64。C# + WinForms，本地运行，无需安装 Python 或 .NET。

## 使用

运行 `MousePower-1.0.0-Setup-x64.exe` 按提示安装。默认安装到当前用户的 `%LOCALAPPDATA%\Programs\MousePower`，无需管理员权限，支持选择安装目录。安装后从开始菜单启动。也可解压便携版，直接运行 `MousePower.exe`。

托盘数字就是选定设备的电量；底部色条显示电量比例，橙色表示低电量，蓝色表示充电。没有可靠读数时显示问号。单击托盘图标打开主界面，右键刷新、切换设备或退出。默认关闭窗口后继续留在托盘，可在设置关闭这一行为。

Windows 可能将图标收进任务栏 `^` 菜单。可以把它拖到电脑电量图标附近，或在 Windows 任务栏设置中开启显示。系统控制托盘位置；本软件不能保证紧挨系统电池图标，也不会替换系统电池图标。

设置中可选择开机自启、30/60/120/300 秒刷新间隔，以及低电量提醒。开机自启默认关闭；便携版启用后不要移动程序，移动后请重新开关自启。仅设备直读的有效读数触发提醒，采样时间未知的 Windows 缓存值不会触发提醒。提醒每个设备在低电量阶段每次运行只提醒一次，回升超过阈值 5% 后重新允许提醒。Windows 勿扰模式可能隐藏通知。

开机自启使用当前用户注册表 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run\MousePower`。设置保存在 `%LOCALAPPDATA%\MousePower\settings.json`。可在 Windows“已安装的应用”中卸载；卸载会清理本软件的自启项和设置。

## 兼容范围

| 通道 | 实现范围 | 实测状态 |
|---|---|---|
| 雷蛇 Razer 2.4G / USB / 部分蓝牙 | 内置 68 个产品 ID 变体，包括多个型号的线缆、接收器版本；见 `Providers/RazerProvider.cs` | 本机 Orochi V2 接收器 `1532:0094` 实机成功，约 90–91%；其他型号未逐一实测 |
| 罗技 Logitech HID++ | 动态发现 HID++ 2.0 `0x1004`、`0x1000` 和 HID++ 1.0 电量寄存器；Unifying/Bolt/LIGHTSPEED 接收器、提供相应接口的蓝牙/USB 直连设备 | 协议测试通过，本机无罗技鼠标，尚未实机验证 |
| 标准蓝牙鼠标 | Windows 电量属性，或标准 BLE Battery Service `0x180F/0x2A19`；适用于提供这些接口的任意品牌，包括微软、戴尔、联想、惠普、华硕等 | 原生枚举与 ABI 测试通过，本机无蓝牙鼠标，GATT 直读尚未实机验证 |
| 其他品牌 2.4G 接收器 | 未实现专有协议 | 不承诺兼容 |

雷蛇系列涵盖 Orochi V2、Atheris、Viper、DeathAdder、Basilisk、Naga、Cobra、Pro Click、Mamba、Lancehead 等已收录 PID。68 个 PID 不等于 68 款独立鼠标，更不代表 68 款均已实测。通用 HyperPolling 接收器可能只显示接收器名称。

罗技仅提供电量档位的设备会显示“电量充足/良好/低/极低”，不会换算为虚假的精确百分比；只提供电压时显示电压。罗技共享接收器内的键盘等设备会明确标注设备类型。不同固件、独占设备的厂商程序及休眠状态可能影响读取。

蓝牙 Windows 属性和 GATT 缓存不保证实时，界面会注明缓存及采样时间未知。设备直读成功才记本次采样时间。设备树中的蓝牙鼠标与耳机、键盘分开识别。无有效电量不显示 0% 冒充读数。

## 排查

移动鼠标唤醒，检查接收器/蓝牙连接，然后刷新。安装厂商驱动或升级鼠标固件前请先遵照厂商说明。如果厂商程序独占接口，可退出该程序后重新读取。软件不会改变 DPI、灯光、配对、休眠或固件设置，不安装额外内核驱动。

“设置 → 导出诊断信息”会保存设备名称、标识、读数来源及状态。文件仅保存在你选择的目录，不会自动上传；分享前可检查内容。应用不联网、不遥测、不自动下载更新。

## 构建

完整源码包含安装脚本、图标、协议测试、原生蓝牙结构测试和应用冒烟测试。安装 [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) 与 [Inno Setup 6.7+](https://jrsoftware.org/isdl.php)，在 PowerShell 执行：

```powershell
.\build.ps1
```

可用 `-Dotnet '路径\dotnet.exe' -Iscc '路径\ISCC.exe'` 指定工具，产物在源码目录下 `dist/`。构建需要首次还原 .NET 运行时包；最终软件离线运行。WinForms 不做不安全裁剪。

命令行：`MousePower.exe --background` 仅托盘运行；`MousePower.exe --diagnose=C:\path\report.json` 只读取一次并退出。GUI 程序在脚本中宜用 `Start-Process -Wait` 等待诊断完成。再次启动应用会唤出已有窗口。

许可证：本项目 MIT；附带 .NET 许可及第三方声明。协议参考与组件归属见 `THIRD_PARTY_NOTICES.md`。此构建未使用商业代码签名证书，Windows 可能显示未知发布者；SHA256 校验值随产物提供。
